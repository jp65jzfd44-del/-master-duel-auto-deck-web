マスターデュエル 自動デッキビルダー Safari / PWA版 v1

■ 目的
Apple Developer Programが有効になるまで、iPhoneのSafariから使う暫定版です。
AltStoreのアプリ枠を消費せず、7日ごとの署名更新も不要です。

■ iPhoneでの使い方
1. HTTPSで公開されたURLをSafariで開く
2. 最初に「カードDBを同期」
3. Safariの共有ボタン →「ホーム画面に追加」
4. 以降はホーム画面の「MDデッキ」から起動

■ PWA版の追加点
- iPhone用「構築 / 結果」タブ
- ホーム画面追加案内
- アプリ本体をService Workerでキャッシュ
- カードDBはIndexedDBへ保存
- 前回生成したデッキも端末内へ保存して復元
- JSON / YDK / 規制JSONはiPhoneでは共有シートで保存可能
- セーフエリア / ホームインジケータ対応

■ 引き継いだ機能
- 日本語テーマ / 日本語カード名
- テーマ選択とフリー検索
- カード画像
- Master Duel N/R/SR/UR
- バランス / 先攻 / 後攻 / 低レア / ネタデッキ
- パチンコ型、パチスロ型、特殊勝利、ロマンなど
- 構築理由 / 基本の動かし方
- Master Duel禁止・制限設定
- JSON / YDK出力

■ 注意
PWAのインストールにはHTTPSでの公開が必要です。ローカルファイルを開くだけではService Workerは利用できません。
Apple Developer Programが有効になったら、固定Bundle IDのネイティブiPhone版へ移行する方針です。
