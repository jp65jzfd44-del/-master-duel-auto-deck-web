(() => {
  'use strict';

  const API_URL = 'https://db.ygoprodeck.com/api/v7/cardinfo.php?format=Master%20Duel&misc=yes';
  const CACHE_KEY = 'master_duel_cards_v1';
  const JP_CACHE_KEY = 'master_duel_japanese_names_v1';
  const REG_KEY = 'master_duel_regulation_v1';
  const LANG_KEY = 'master_duel_display_language_v1';
  const IMAGE_KEY = 'master_duel_card_image_display_v1';
  const LAST_DECK_KEY = 'master_duel_last_deck_v1';
  const JP_SEARCH_URL = 'https://ygocdb.com/api/v0/?search=';
  const JP_CARDSET_URL = 'https://ygocdb.com/api/v0/cardset';
  const JP_CARD_URL = 'https://ygocdb.com/api/v0/card/';
  const CACHE_MAX_AGE = 24 * 60 * 60 * 1000;
  const PRESETS = window.MD_REG_PRESETS || {};

  const $ = (id) => document.getElementById(id);

  const state = {
    cards: [],
    cardByName: new Map(),
    cardById: new Map(),
    archetypes: [],
    cardByJpName: new Map(),
    jpNameCache: {},
    regulation: PRESETS.current ? JSON.parse(JSON.stringify({ ...PRESETS.current, preset_id: 'current' })) : { name: 'Master Duel custom regulation', effective_date: '', source: 'User-maintained', limits: {}, preset_id: 'custom' },
    deck: null,
  };

  const JP_ARCHETYPE_ALIASES = {
    '青眼': 'Blue-Eyes',
    'ブルーアイズ': 'Blue-Eyes',
    'ブラックマジシャン': 'Dark Magician',
    'ブラック・マジシャン': 'Dark Magician',
    '閃刀姫': 'Sky Striker',
    '烙印': 'Branded',
    'デスピア': 'Despia',
    'ラビュリンス': 'Labrynth',
    'ティアラメンツ': 'Tearlaments',
    'スネークアイ': 'Snake-Eye',
    'スネークアイ': 'Snake-Eye',
    'ユベル': 'Yubel',
    'センチュリオン': 'Centur-Ion',
    'ホルス': 'Horus',
    '粛声': 'Voiceless Voice',
    'レスキューエース': 'Rescue-ACE',
    'レスキューACE': 'Rescue-ACE',
    'キマイラ': 'Chimera',
    'ドラゴンメイド': 'Dragonmaid',
    'サイバードラゴン': 'Cyber Dragon',
    'サイバー・ドラゴン': 'Cyber Dragon',
    '六武衆': 'Six Samurai',
    'BF': 'Blackwing',
    'ブラックフェザー': 'Blackwing',
    'HERO': 'HERO',
    'ヒーロー': 'HERO',
    'エルドリッチ': 'Eldlich',
    '鉄獣戦線': 'Tri-Brigade',
    'トライブリゲード': 'Tri-Brigade',
    '十二獣': 'Zoodiac',
    'ふわんだりぃず': 'Floowandereeze',
    'ピュアリィ': 'Purrely',
    '御巫': 'Mikanko',
    'みかんこ': 'Mikanko',
    'ヴァリアンツ': 'Vaylantz',
    'ドラグマ': 'Dogmatika',
    'エクソシスター': 'Exosister',
    'マドルチェ': 'Madolche',
    'メメント': 'Memento',
    '天盃龍': 'Tenpai Dragon',
    '天盃': 'Tenpai Dragon',
    '白き森': 'White Forest',
    'ライゼオル': 'Ryzeal',
    'マリス': 'Maliss',
    'M∀LICE': 'Maliss',
    'ミミグル': 'Mimighoul',
    'ミミグール': 'Mimighoul',
    'MIMIGHOUL': 'Mimighoul',
    'アザミナ': 'Azamina',
    'デモンスミス': 'Fiendsmith',
    '原石': 'Primite',
    'ライゼオル': 'Ryzeal'
  };



  // 画面表示用の日本語テーマ名。内部ではAPIの英語アーキタイプ名を保持する。
  // ユーザーに見えるテーマ名は原則としてこの日本語名を使う。
  const JP_ARCHETYPE_NAMES = {
    'Blue-Eyes': '青眼',
    'Dark Magician': 'ブラック・マジシャン',
    'Red-Eyes': 'レッドアイズ',
    'Sky Striker': '閃刀姫',
    'Branded': '烙印',
    'Despia': 'デスピア',
    'Labrynth': 'ラビュリンス',
    'Tearlaments': 'ティアラメンツ',
    'Snake-Eye': 'スネークアイ',
    'Yubel': 'ユベル',
    'Centur-Ion': 'センチュリオン',
    'Horus': 'ホルス',
    'Voiceless Voice': '粛声',
    'Rescue-ACE': 'R－ACE',
    'Chimera': 'キマイラ',
    'Dragonmaid': 'ドラゴンメイド',
    'Cyber Dragon': 'サイバー・ドラゴン',
    'Cyberdark': 'サイバー・ダーク',
    'Six Samurai': '六武衆',
    'Blackwing': 'BF',
    'HERO': 'HERO',
    'Elemental HERO': 'E・HERO',
    'Destiny HERO': 'D-HERO',
    'Vision HERO': 'V・HERO',
    'Evil HERO': 'E-HERO',
    'Masked HERO': 'M・HERO',
    'Eldlich': 'エルドリッチ',
    'Tri-Brigade': '鉄獣戦線',
    'Zoodiac': '十二獣',
    'Floowandereeze': 'ふわんだりぃず',
    'Purrely': 'ピュアリィ',
    'Mikanko': '御巫',
    'Vaylantz': 'ヴァリアンツ',
    'Dogmatika': 'ドラグマ',
    'Exosister': 'エクソシスター',
    'Madolche': 'マドルチェ',
    'Memento': 'メメント',
    'Tenpai Dragon': '天盃龍',
    'White Forest': '白き森',
    'Ryzeal': 'ライゼオル',
    'Maliss': 'M∀LICE',
    'Mimighoul': 'ミミグル',
    'Azamina': 'アザミナ',
    'Fiendsmith': 'デモンスミス',
    'Primite': '原石',
    'Spright': 'スプライト',
    'Kashtira': 'クシャトリラ',
    'Scareclaw': 'スケアクロー',
    'Mannadium': 'マナドゥム',
    'Swordsoul': '相剣',
    'Tenyi': '天威',
    'Virtual World': '電脳堺',
    'Drytron': '竜輝巧',
    'Adamancipator': 'アダマシア',
    'D/D': 'D/D',
    'D/D/D': 'D/D/D',
    'Mathmech': '斬機',
    'Code Talker': 'コード・トーカー',
    'Salamangreat': '転生炎獣',
    'Marincess': '海晶乙女',
    'Unchained': '破械',
    'Live☆Twin': 'Live☆Twin',
    'Evil★Twin': 'Evil★Twin',
    'Runick': '神碑',
    'Naturia': 'ナチュル',
    'Fur Hire': '空牙団',
    'Plunder Patroll': '海造賊',
    'P.U.N.K.': 'P.U.N.K.',
    'Gold Pride': 'ゴールド・プライド',
    'Therion': 'セリオンズ',
    'Phantom Knights': '幻影騎士団',
    'The Phantom Knights': '幻影騎士団',
    'Burning Abyss': '彼岸',
    'Raidraptor': 'RR',
    'Black Luster Soldier': 'カオス・ソルジャー',
    'Gaia The Fierce Knight': '暗黒騎士ガイア',
    'Galaxy': 'ギャラクシー',
    'Photon': 'フォトン',
    'Utopia': 'ホープ',
    'Onomat': 'オノマト',
    'Performapal': 'EM',
    'Odd-Eyes': 'オッドアイズ',
    'Magician': '魔術師',
    'Predaplant': '捕食植物',
    'Speedroid': 'SR',
    'Synchron': 'シンクロン',
    'Stardust': 'スターダスト',
    'Resonator': 'リゾネーター',
    'Red Dragon Archfiend': 'レッド・デーモン',
    'Neo-Spacian': 'N',
    'Neos': 'ネオス',
    'Ancient Gear': '古代の機械',
    'Crystal Beast': '宝玉獣',
    'Toon': 'トゥーン',
    'Relinquished': 'サクリファイス',
    'Traptrix': '蟲惑魔',
    'Aroma': 'アロマ',
    'Rikka': '六花',
    'Sunavalon': 'サンアバロン',
    'Infernoble Knight': '焔聖騎士',
    'Noble Knight': '聖騎士',
    'Infernity': 'インフェルニティ',
    'Lightsworn': 'ライトロード',
    'Shaddoll': 'シャドール',
    'Invoked': '召喚獣',
    'Witchcrafter': 'ウィッチクラフト',
    'Endymion': 'エンディミオン',
    'Dracoslayer': '竜剣士',
    'Dinomorphia': 'ダイノルフィア',
    'True Draco': '真竜',
    'Monarch': '帝',
    'Subterror': 'サブテラー',
    'Altergeist': 'オルターガイスト',
    'Paleozoic': 'バージェストマ',
    'Frog': 'ガエル',
    'Ninja': '忍者',
    'Mayakashi': '魔妖',
    'Shiranui': '不知火',
    'Vampire': 'ヴァンパイア',
    'Vendread': 'ヴェンデット',
    'Evil Eye': '呪眼',
    'Dark World': '暗黒界',
    'Fabled': '魔轟神',
    'Lunalight': '月光',
    'Fluffal': 'ファーニマル',
    'Frightfur': 'デストーイ',
    'Edge Imp': 'エッジインプ',
    'Melffy': 'メルフィー',
    'Ancient Warriors': '戦華',
    'Fire King': '炎王',
    'Fire Fist': '炎星',
    'Volcanic': 'ヴォルカニック',
    "Battlin' Boxer": 'BK',
    'Tellarknight': 'テラナイト',
    'Constellar': 'セイクリッド',
    'Hieratic': '聖刻',
    'Dragon Ruler': '征竜',
    'Dragunity': 'ドラグニティ',
    'Rokket': 'ヴァレット',
    'Borrel': 'ヴァレル',
    'Bystial': 'ビーステッド',
    'Chaos': 'カオス',
    'Thunder Dragon': 'サンダー・ドラゴン',
    'Metaphys': 'メタファイズ',
    'Mekk-Knight': '機界騎士',
    'World Legacy': '星遺物',
    'Orcust': 'オルフェゴール',
    'Crusadia': 'パラディオン',
    'Krawler': 'クローラー',
    'Knightmare': 'トロイメア',
    'Guardragon': '守護竜',
    'World Chalice': '星杯',
    'Nemleria': 'ネムレリア',
    'Vanquish Soul': 'VS',
    'Nouvelles': 'ヌーベルズ',
    'Nemeses': 'ネメシス',
    'Magikey': '魔鍵',
    'Libromancer': 'リブロマンサー',
    'Nekroz': '影霊衣',
    'Megalith': 'メガリス',
    'Gishki': 'リチュア',
    'Ritual Beast': '霊獣',
    'Infernoid': 'インフェルノイド',
    'Qliphort': 'クリフォート',
    'Metalfoes': 'メタルフォーゼ',
    'Dinomist': 'ダイナミスト',
    'Majespecter': 'マジェスペクター',
    'Igknight': 'イグナイト',
    'Amorphage': 'アモルファージ',
    'Zefra': 'セフィラ',
    'Yang Zing': '竜星',
    'Karakuri': 'カラクリ',
    'Superheavy Samurai': '超重武者',
    'Flower Cardian': '花札衛',
    'Gimmick Puppet': 'ギミック・パペット',
    'Chronomaly': '先史遺産',
    'Heraldic Beast': '紋章獣',
    'Abyss Actor': '魔界劇団',
    'Solfachord': 'ドレミコード',
    'Vaalmonica': 'ヴァルモニカ',
    'Dream Mirror': '夢魔鏡',
    'Generaider': '王',
    'Myutant': 'ミュートリア',
    'Ghoti': 'ゴーティス',
    'Icejade': '氷水',
    'Mermail': '水精鱗',
    'Atlantean': '海皇',
    'Tistina': 'ティスティナ',
    'Gate Guardian': 'ゲート・ガーディアン',
    'Mokey Mokey': 'もけもけ',
    'Ojama': 'おジャマ',
    'Armed Dragon': 'アームド・ドラゴン',
    'ABC': 'ABC',
    'Kozmo': 'Kozmo',
    'Kaiju': '壊獣',
    'Graydle': 'グレイドル',
    'PSY-Frame': 'PSYフレーム',
    'Aromage': 'アロマージ',
    'Performage': 'Em',
    'Prediction Princess': '占術姫',
    'Aquactress': 'アクアアクトレス',
    'Raidraptor': 'RR',
    'Jinzo': '人造人間－サイコ・ショッカー',
    'Charmers': '霊使い',
    'Charmer': '霊使い',
    'Possessed': '憑依装着',
    'Buster Blader': 'バスター・ブレイダー',
    'Destruction Sword': '破壊剣',
    'Aesir': '極神',
    'Nordic': '極星',
    'Gladiator Beast': '剣闘獣',
    'Gravekeeper': '墓守',
    "Gravekeeper's": '墓守',
    'Ice Barrier': '氷結界',
    'Watt': 'エレキ',
    'Gusto': 'ガスタ',
    'Scrap': 'スクラップ',
    'Meklord': '機皇',
    'Machina': 'マシンナーズ',
    'Infinitrack': '無限起動',
    'Railway': '列車',
    'Super Quant': '超量',
    'Time Thief': 'クロノダイバー',
    'Phantasm Spiral': '幻煌龍',
    'Spyral': 'SPYRAL',
    'SPYRAL': 'SPYRAL',
    'Lair of Darkness': '闇黒世界',
    'Weather Painter': '天気',
    'The Weather': '天気',
    'Trickstar': 'トリックスター',
    'Prank-Kids': 'プランキッズ',
    'Mekk-Knight': '機界騎士',
    'Dinowrestler': 'ダイナレスラー',
    'Gouki': '剛鬼',
    'Altergeist': 'オルターガイスト',
    'Appliancer': '機塊',
    '@Ignister': '＠イグニスター',
    'Ignister': '＠イグニスター',
    'Dragon Link': 'ドラゴンリンク',
    'Sacred Beast': '三幻魔',
    'Earthbound': '地縛',
    'Earthbound Immortal': '地縛神',
    'Malefic': 'Sin',
    'Timelord': '時械神',
    'Numeron': 'ヌメロン',
    'Meklord Emperor': '機皇帝',
    'Arcana Force': 'アルカナフォース',
    'Amazoness': 'アマゾネス',
    'Alien': 'エーリアン',
    'X-Saber': 'X－セイバー',
    'XX-Saber': 'XX－セイバー',
    'Cloudian': '雲魔物',
    'Morphtronic': 'D（ディフォーマー）',
    'T.G.': 'TG',
    'Batteryman': '電池メン',
    'Flamvell': 'フレムベル',
    'Vylon': 'ヴァイロン',
    'Fortune Lady': 'フォーチュンレディ',
    'Yosenju': '妖仙獣',
    'Zefra': 'セフィラ',
    'Kozmo': 'Kozmo',
    'Paleozoic': 'バージェストマ'
  };

  const STAPLES = {
    balanced: [
      ['Maxx "C"', 3],
      ['Ash Blossom & Joyous Spring', 3],
      ['Infinite Impermanence', 3],
      ['Called by the Grave', 2],
      ['Crossout Designator', 1],
      ['Effect Veiler', 1],
      ['Nibiru, the Primal Being', 1],
      ['Triple Tactics Talent', 1],
      ['Droll & Lock Bird', 1]
    ],
    first: [
      ['Maxx "C"', 3],
      ['Ash Blossom & Joyous Spring', 3],
      ['Infinite Impermanence', 3],
      ['Called by the Grave', 2],
      ['Crossout Designator', 1],
      ['Effect Veiler', 2],
      ['Solemn Judgment', 1],
      ['Droll & Lock Bird', 1]
    ],
    second: [
      ['Maxx "C"', 3],
      ['Ash Blossom & Joyous Spring', 3],
      ['Infinite Impermanence', 3],
      ['Nibiru, the Primal Being', 2],
      ['Evenly Matched', 2],
      ['Lightning Storm', 1],
      ["Harpie's Feather Duster", 1],
      ['Triple Tactics Talent', 1],
      ['Triple Tactics Thrust', 1]
    ],
    budget: [
      ['Ash Blossom & Joyous Spring', 2],
      ['Effect Veiler', 2],
      ['Book of Moon', 2],
      ['Forbidden Chalice', 2],
      ['Cosmic Cyclone', 1],
      ['Compulsory Evacuation Device', 1]
    ]
  };

  const GENERIC_EXTRA = [
    'S:P Little Knight',
    'I:P Masquerena',
    'Knightmare Unicorn',
    'Accesscode Talker',
    'Underworld Goddess of the Closed World',
    'Apollousa, Bow of the Goddess',
    'Super Starslayer TY-PHON - Sky Crisis',
    'Divine Arsenal AA-ZEUS - Sky Thunder',
    'Baronne de Fleur',
    'Borreload Savage Dragon',
    'Chaos Angel',
    'Garura, Wings of Resonant Life',
    'Mudragon of the Swamp',
    'Predaplant Dragostapelia'
  ];

  const JOKE_TYPE_LABELS = {
    auto: '自動判定',
    pachinko: 'パチンコ型（大当たり・連チャン狙い）',
    slot: 'パチスロ型（コイン・サイコロ連続判定）',
    romance: 'ロマンコンボ・大型エース',
    altwin: '特殊勝利',
    gamble: '運試し（コイン・サイコロ）',
    otk: '一撃必殺・ワンキル',
    burn: 'バーン・効果ダメージ',
    mill: 'デッキ破壊・墓地送り',
    lock: 'ロック・行動制限',
    vanilla: '通常モンスター・バニラ',
    levelone: 'レベル1・低レベル',
    muscle: '高打点・脳筋',
    selfburn: '自爆・LP極限',
    restriction: '縛り・特定条件',
    character: 'キャラ・原作再現',
    chaos: 'カオス・ごちゃまぜ'
  };

  const JOKE_LEVEL_LABELS = {
    practical: '実戦寄り',
    balanced: '半々',
    allin: '全振り'
  };

  const CHARACTER_THEME_ALIASES = {
    '海馬': 'Blue-Eyes',
    '海馬瀬人': 'Blue-Eyes',
    '遊戯': 'Dark Magician',
    '闇遊戯': 'Dark Magician',
    '武藤遊戯': 'Dark Magician',
    '城之内': 'Red-Eyes',
    '城之内克也': 'Red-Eyes',
    '十代': 'HERO',
    '遊城十代': 'HERO',
    '遊星': 'Synchron',
    '不動遊星': 'Synchron',
    'ジャック': 'Resonator',
    'ジャックアトラス': 'Resonator',
    'カイト': 'Galaxy',
    '天城カイト': 'Galaxy',
    '遊馬': 'Utopia',
    '九十九遊馬': 'Utopia',
    '遊矢': 'Performapal',
    '榊遊矢': 'Performapal',
    '遊作': 'Code Talker',
    '藤木遊作': 'Code Talker'
  };

  const JOKE_KEYWORD_RULES = [
    { keys: ['コイントス', 'コイン', 'coin'], label: 'コイントス', test: c => /coin toss|toss a coin|heads|tails/i.test(String(c.desc || '')) },
    { keys: ['サイコロ', 'ダイス', 'dice', 'die'], label: 'サイコロ', test: c => /six-sided die|die result|dice roll|roll a die/i.test(String(c.desc || '')) },
    { keys: ['特殊勝利', '勝利条件', 'win the duel'], label: '特殊勝利', test: c => /win the duel/i.test(String(c.desc || '')) },
    { keys: ['エクゾディア', 'exodia'], label: 'エクゾディア', test: c => /exodia|forbidden one/i.test(`${c.name || ''} ${c.desc || ''}`) },
    { keys: ['ワイト', 'wight', 'skull servant'], label: 'ワイト', test: c => /wight|skull servant/i.test(`${c.name || ''} ${c.archetype || ''} ${c.desc || ''}`) },
    { keys: ['バーン', '効果ダメージ', 'burn'], label: 'バーン', test: c => /inflict .*damage|effect damage/i.test(String(c.desc || '')) },
    { keys: ['デッキ破壊', 'デッキデス', 'mill'], label: 'デッキ破壊', test: c => /top .*deck.*(?:gy|graveyard)|send .* from the top of .*deck|deck to the gy/i.test(String(c.desc || '')) },
    { keys: ['直接攻撃', 'ダイレクトアタック', 'direct attack'], label: '直接攻撃', test: c => /attack directly|direct attack/i.test(String(c.desc || '')) },
    { keys: ['回復', 'lp回復', 'ライフゲイン'], label: 'LP回復', test: c => /gain .*lp|gain .*life points|increase .*lp/i.test(String(c.desc || '')) },
    { keys: ['通常モンスター', 'バニラ'], label: '通常モンスター', test: c => /Normal Monster/i.test(String(c.type || '')) },
    { keys: ['トークン'], label: 'トークン', test: c => /token/i.test(String(c.desc || '')) },
    { keys: ['自爆', '自傷'], label: '自傷・自爆', test: c => /pay .*lp|halve your lp|take .*damage|inflict .*damage to you/i.test(String(c.desc || '')) },
    { keys: ['パチンコ', '大当たり', '連チャン', '確変'], label: 'パチンコ型', test: c => /coin toss|toss a coin|six-sided die|roll a die|die result|draw [12]|excavate|random|inflict .*damage/i.test(String(c.desc || '')) },
    { keys: ['パチスロ', 'スロット', 'ジャックポット'], label: 'パチスロ型', test: c => /coin toss|toss a coin|six-sided die|roll a die|die result|number of heads|number rolled/i.test(String(c.desc || '')) },
    { keys: ['一撃必殺', 'ワンキル', 'otk'], label: '一撃必殺', test: c => /attack directly|can make a second attack|attack twice|double .*battle damage|inflict double|gains? .*atk/i.test(String(c.desc || '')) || Number(c.atk || 0) >= 3000 },
    { keys: ['ロック', '封殺', '行動制限'], label: 'ロック', test: c => /cannot (?:activate|attack|summon)|neither player can|your opponent cannot|skip .* phase|negate .* activation/i.test(String(c.desc || '')) },
    { keys: ['高打点', '脳筋', 'パワー'], label: '高打点', test: c => Number(c.atk || 0) >= 3000 }
  ];

  function normalizeText(s) {
    return String(s || '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
  }

  function preferredThemeAliases() {
    const byArchetype = new Map(Object.entries(JP_ARCHETYPE_NAMES));
    for (const [label, archetype] of Object.entries(JP_ARCHETYPE_ALIASES)) {
      if (!archetype) continue;
      const current = byArchetype.get(archetype);
      const candidateIsJp = looksJapanese(label) || /[∀★☆＠・－]/.test(label);
      const currentIsJp = current ? (looksJapanese(current) || /[∀★☆＠・－]/.test(current)) : false;
      if (!current || (candidateIsJp && !currentIsJp)) byArchetype.set(archetype, label);
    }
    return byArchetype;
  }

  function themeDisplayName(archetype, fallback = '') {
    const value = String(archetype || '').trim();
    const aliases = preferredThemeAliases();
    const label = aliases.get(value) || String(fallback || '').trim();
    if (label && (looksJapanese(label) || /[∀★☆＠・－]/.test(label))) return label;
    return value ? '日本語名未登録テーマ' : 'テーマなし';
  }

  function populateThemeSelect() {
    const select = $('themeSelect');
    if (!select) return;
    const previous = String(select.value || '');
    const aliases = preferredThemeAliases();

    select.innerHTML = '';
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = $('profileSelect')?.value === 'joke'
      ? 'テーマなしでもOK / 選択してください ▼'
      : 'テーマを選択してください ▼';
    empty.dataset.displayLabel = '';
    select.appendChild(empty);

    const registeredGroup = document.createElement('optgroup');
    registeredGroup.label = 'テーマ一覧（日本語）';
    const registered = [...aliases.entries()]
      .sort((a, b) => String(a[1]).localeCompare(String(b[1]), 'ja'));
    for (const [archetype, label] of registered) {
      const opt = document.createElement('option');
      opt.value = archetype;
      opt.textContent = label;
      opt.dataset.displayLabel = label;
      registeredGroup.appendChild(opt);
    }
    select.appendChild(registeredGroup);

    if (state.archetypes.length) {
      const aliasValues = new Set(aliases.keys());
      const untranslated = state.archetypes.filter(a => !aliasValues.has(a));
      if (untranslated.length) {
        const infoGroup = document.createElement('optgroup');
        infoGroup.label = 'その他';
        const info = document.createElement('option');
        info.value = '';
        info.disabled = true;
        info.textContent = `日本語名未登録のテーマはフリー検索から指定できます（${untranslated.length}件）`;
        infoGroup.appendChild(info);
        select.appendChild(infoGroup);
      }
    }

    if (previous) setThemeSelection(previous);
  }

  function ensureThemeOption(archetype, label = '') {
    const select = $('themeSelect');
    const value = String(archetype || '').trim();
    if (!select || !value) return null;
    const existing = [...select.options].find(opt => opt.value === value);
    if (existing) {
      if (label && !existing.dataset.displayLabel) existing.dataset.displayLabel = label;
      return existing;
    }
    let group = [...select.querySelectorAll('optgroup')].find(g => g.label === '検索から追加');
    if (!group) {
      group = document.createElement('optgroup');
      group.label = '検索から追加';
      select.appendChild(group);
    }
    const opt = document.createElement('option');
    opt.value = value;
    const visibleLabel = themeDisplayName(value, label);
    opt.textContent = visibleLabel;
    opt.dataset.displayLabel = visibleLabel;
    group.appendChild(opt);
    return opt;
  }

  function setThemeSelection(archetype, label = '') {
    const select = $('themeSelect');
    if (!select) return;
    const option = ensureThemeOption(archetype, label);
    if (!option) return;
    select.value = option.value;
  }

  function selectedThemeLabel() {
    const select = $('themeSelect');
    if (!select || !select.value) return '';
    const opt = select.selectedOptions?.[0];
    return String(opt?.dataset?.displayLabel || opt?.textContent || select.value).trim();
  }

  function freeThemeMatches(query) {
    const target = normalizeText(query);
    if (!target) return [];
    const aliases = preferredThemeAliases();
    const results = new Map();
    const add = (archetype, label, score) => {
      if (!archetype || score <= 0) return;
      const prev = results.get(archetype);
      if (!prev || score > prev.score) results.set(archetype, { archetype, label: label || archetype, score });
    };

    for (const [archetype, label] of aliases) {
      const jp = normalizeText(label);
      const en = normalizeText(archetype);
      let score = 0;
      if (jp === target || en === target) score = 300;
      else if (jp.startsWith(target) || en.startsWith(target)) score = 220;
      else if (jp.includes(target) || en.includes(target)) score = 160;
      add(archetype, label, score);
    }

    for (const archetype of state.archetypes) {
      const en = normalizeText(archetype);
      let score = 0;
      if (en === target) score = 290;
      else if (en.startsWith(target)) score = 210;
      else if (en.includes(target)) score = 150;
      add(archetype, aliases.get(archetype) || '日本語名未登録テーマ', score);
    }
    return [...results.values()].sort((a, b) => b.score - a.score || a.label.localeCompare(b.label, 'ja'));
  }

  function freeCardScore(card, query) {
    const target = normalizeText(query);
    if (!card || !target) return -1;
    const names = [card.name, card.jp_name, card.jp_ruby].filter(Boolean).map(normalizeText);
    let score = -1;
    if (names.some(n => n === target)) score = Math.max(score, 320);
    if (names.some(n => n.startsWith(target))) score = Math.max(score, 240);
    if (names.some(n => n.includes(target))) score = Math.max(score, 190);
    const archetype = normalizeText(card.archetype);
    if (archetype === target) score = Math.max(score, 180);
    else if (archetype.includes(target)) score = Math.max(score, 130);
    const desc = normalizeText(card.desc);
    if (target.length >= 3 && desc.includes(target)) score = Math.max(score, 65);
    return score;
  }

  function renderFreeSearchResults(themeMatches, cardMatches, query) {
    const host = $('freeSearchResults');
    if (!host) return;
    host.innerHTML = '';

    if (!themeMatches.length && !cardMatches.length) {
      const empty = document.createElement('div');
      empty.className = 'free-search-empty';
      empty.textContent = `「${query}」に一致するテーマ・カードが見つかりませんでした。`;
      host.appendChild(empty);
      return;
    }

    if (themeMatches.length) {
      const title = document.createElement('div');
      title.className = 'free-result-section-title';
      title.textContent = 'テーマ候補';
      host.appendChild(title);
      for (const item of themeMatches.slice(0, 8)) {
        const row = document.createElement('div');
        row.className = 'free-result free-theme-result';
        const info = document.createElement('div');
        info.className = 'free-result-info';
        const strong = document.createElement('strong');
        strong.textContent = item.label;
        const sub = document.createElement('span');
        sub.textContent = 'テーマ';
        info.append(strong, sub);
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'テーマに設定';
        button.dataset.action = 'set-theme';
        button.dataset.theme = item.archetype;
        button.dataset.themeLabel = item.label;
        row.append(info, button);
        host.appendChild(row);
      }
    }

    if (cardMatches.length) {
      const title = document.createElement('div');
      title.className = 'free-result-section-title';
      title.textContent = 'カード候補';
      host.appendChild(title);
      for (const card of cardMatches.slice(0, 12)) {
        const row = document.createElement('div');
        row.className = 'free-result free-card-result';
        row.dataset.cardId = String(card.id);

        if (imageDisplayEnabled()) {
          const urls = cardImageUrls(card);
          const imgBtn = document.createElement('button');
          imgBtn.type = 'button';
          imgBtn.className = 'free-card-thumb';
          imgBtn.dataset.action = 'show-card';
          imgBtn.dataset.cardId = String(card.id);
          if (urls.small) {
            const img = document.createElement('img');
            img.src = urls.small;
            img.alt = `${displayName(card)} の画像`;
            img.loading = 'lazy';
            imgBtn.appendChild(img);
          } else {
            imgBtn.textContent = '画像';
          }
          row.appendChild(imgBtn);
        }

        const info = document.createElement('div');
        info.className = 'free-result-info';
        const strong = document.createElement('strong');
        strong.textContent = displayName(card);
        const sub = document.createElement('span');
        sub.textContent = `${card.archetype ? themeDisplayName(card.archetype) : 'テーマなし'} / ${mdRarityLabel(card)}`;
        info.append(strong, sub);
        row.appendChild(info);

        const actions = document.createElement('div');
        actions.className = 'free-result-actions';
        const must = document.createElement('button');
        must.type = 'button';
        must.textContent = '必須に追加';
        must.dataset.action = 'add-must';
        must.dataset.cardId = String(card.id);
        actions.appendChild(must);
        if (card.archetype) {
          const theme = document.createElement('button');
          theme.type = 'button';
          theme.textContent = 'テーマに設定';
          theme.dataset.action = 'set-card-theme';
          theme.dataset.cardId = String(card.id);
          actions.appendChild(theme);
        }
        row.appendChild(actions);
        host.appendChild(row);
      }
    }
  }

  function appendMustCard(card) {
    if (!card) return;
    const textarea = $('mustInput');
    if (!textarea) return;
    const existing = linesToNames(textarea.value);
    const cardNames = [card.name, card.jp_name, card.jp_ruby].filter(Boolean).map(normalizeText);
    if (existing.some(name => cardNames.includes(normalizeText(name)))) {
      setHint(`「${displayName(card)}」はすでに必須カードに入っています。`, 'notice');
      return;
    }
    const addName = card.jp_name || card.name;
    textarea.value = [...existing, addName].join('\n');
    setHint(`「${displayName(card)}」を必須カードに追加しました。`, 'ok');
  }

  async function runFreeSearch() {
    const input = $('freeSearchInput');
    const button = $('freeSearchBtn');
    const host = $('freeSearchResults');
    const query = String(input?.value || '').trim();
    if (!query) {
      if (host) host.innerHTML = '<div class="free-search-empty">検索したいカード名・テーマ名・キーワードを入力してください。</div>';
      return;
    }
    if (!state.cards.length) {
      setHint('フリー検索を使う前にカードDBを同期してください。', 'error');
      if (host) host.innerHTML = '<div class="free-search-empty">先に「カードDBを同期」を押してください。</div>';
      return;
    }

    if (button) button.disabled = true;
    if (host) host.innerHTML = '<div class="free-search-empty">検索中…</div>';
    try {
      const themeMatches = freeThemeMatches(query);
      const scored = state.cards
        .map(card => ({ card, score: freeCardScore(card, query) }))
        .filter(x => x.score >= 0)
        .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card));
      const byId = new Map(scored.slice(0, 30).map(x => [String(x.card.id), x]));

      if (looksJapanese(query) || byId.size < 8) {
        const jpResults = await searchJapaneseCards(query);
        for (const result of jpResults.slice(0, 30)) {
          const card = mapJapaneseResultToCard(result);
          if (!card) continue;
          const score = Math.max(260, freeCardScore(card, query));
          const key = String(card.id);
          const prev = byId.get(key);
          if (!prev || score > prev.score) byId.set(key, { card, score });
        }
        rebuildJapaneseIndex();
        await saveJapaneseCache();
      }

      const cardMatches = [...byId.values()]
        .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card))
        .slice(0, 12)
        .map(x => x.card);
      renderFreeSearchResults(themeMatches, cardMatches, query);
    } catch (err) {
      if (host) host.innerHTML = `<div class="free-search-empty">検索中にエラーが発生しました: ${String(err.message || err)}</div>`;
    } finally {
      if (button) button.disabled = false;
    }
  }

  function handleFreeSearchAction(ev) {
    const button = ev.target.closest('[data-action]');
    if (!button) return;
    const action = button.dataset.action;
    if (action === 'set-theme') {
      setThemeSelection(button.dataset.theme || '', button.dataset.themeLabel || '');
      setHint(`テーマを「${button.dataset.themeLabel || button.dataset.theme || ''}」に設定しました。`, 'ok');
      return;
    }
    const card = state.cardById.get(String(button.dataset.cardId || ''));
    if (!card) return;
    if (action === 'add-must') {
      appendMustCard(card);
    } else if (action === 'set-card-theme' && card.archetype) {
      const label = themeDisplayName(card.archetype, card.jp_name ? `${card.jp_name}関連` : '日本語名未登録テーマ');
      setThemeSelection(card.archetype, label);
      setHint(`「${displayName(card)}」のテーマ「${label}」を設定しました。`, 'ok');
    } else if (action === 'show-card') {
      openCardImage(card);
    }
  }

  function linesToNames(s) {
    return String(s || '')
      .split(/[\n,;]+/)
      .map(v => v.trim())
      .filter(Boolean);
  }

  function looksJapanese(s) {
    return /[\u3040-\u30ff\u3400-\u9fff\uff66-\uff9f]/.test(String(s || ''));
  }

  function currentDisplayLanguage() {
    return $('displayLang')?.value || localStorage.getItem(LANG_KEY) || 'jp';
  }

  function displayName(card) {
    if (!card) return '';
    const lang = currentDisplayLanguage();
    const jp = String(card.jp_name || '').trim();
    const en = String(card.name || '').trim();
    if (lang === 'en') return en || jp;
    if (lang === 'both') return jp ? `${jp} / ${en}` : en;
    return jp || en;
  }

  function cardImageUrls(card) {
    if (!card) return { small: '', large: '' };
    const list = Array.isArray(card.card_images) ? card.card_images : [];
    const own = list.find(x => String(x?.id || '') === String(card.id || '')) || list[0] || {};
    const id = String(card.id || '').trim();
    return {
      small: own.image_url_small || (id ? `https://images.ygoprodeck.com/images/cards_small/${encodeURIComponent(id)}.jpg` : ''),
      large: own.image_url || (id ? `https://images.ygoprodeck.com/images/cards/${encodeURIComponent(id)}.jpg` : '')
    };
  }

  function imageDisplayEnabled() {
    return ($('imageDisplay')?.value || localStorage.getItem(IMAGE_KEY) || 'show') !== 'hide';
  }

  function openCardImage(card) {
    const modal = $('cardImageModal');
    const img = $('cardImageLarge');
    if (!modal || !img || !card) return;
    const urls = cardImageUrls(card);
    if (!urls.large && !urls.small) return;
    $('cardImageTitle').textContent = displayName(card);
    const en = String(card.name || '').trim();
    const rarity = mdRarityLabel(card);
    $('cardImageSub').textContent = currentDisplayLanguage() === 'jp' && card.jp_name && en
      ? `${en} / ${rarity}`
      : rarity;
    img.alt = `${displayName(card)} のカード画像`;
    img.src = urls.large || urls.small;
    img.onerror = () => {
      if (urls.small && img.src !== urls.small) img.src = urls.small;
    };
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    setTimeout(() => $('cardImageClose')?.focus(), 0);
  }

  function closeCardImage() {
    const modal = $('cardImageModal');
    const img = $('cardImageLarge');
    if (!modal) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    if (img) {
      img.removeAttribute('src');
      img.onerror = null;
    }
  }

  function japaneseInfoFromRecord(record) {
    if (!record || typeof record !== 'object') return null;
    const text = record.text && typeof record.text === 'object' ? record.text : {};
    const jpName = record.jp_name || text.jp_name || '';
    const jpRuby = record.jp_ruby || text.jp_ruby || '';
    const enName = record.en_name || text.en_name || '';
    if (!jpName && !jpRuby && !enName) return null;
    return {
      jp_name: String(jpName || ''),
      jp_ruby: String(jpRuby || ''),
      en_name: String(enName || '')
    };
  }

  function applyJapaneseInfo(card, record, persist = true) {
    if (!card || !card.id) return false;
    const info = japaneseInfoFromRecord(record);
    if (!info) return false;
    if (info.jp_name) card.jp_name = info.jp_name;
    if (info.jp_ruby) card.jp_ruby = info.jp_ruby;
    if (info.en_name) card.jp_source_en_name = info.en_name;
    if (persist) state.jpNameCache[String(card.id)] = info;
    return true;
  }

  function rebuildJapaneseIndex() {
    state.cardByJpName = new Map();
    for (const card of state.cards) {
      for (const name of [card.jp_name, card.jp_ruby]) {
        const key = normalizeText(name);
        if (key && !state.cardByJpName.has(key)) state.cardByJpName.set(key, card);
      }
    }
  }

  async function loadJapaneseCache() {
    const cached = await cacheGet(JP_CACHE_KEY);
    state.jpNameCache = cached && cached.names && typeof cached.names === 'object' ? cached.names : {};
  }

  async function saveJapaneseCache() {
    await cacheSet(JP_CACHE_KEY, { timestamp: Date.now(), names: state.jpNameCache });
  }

  async function fetchJsonWithTimeout(url, options = {}, timeoutMs = 9000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal, cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } finally {
      clearTimeout(timer);
    }
  }

  function mapJapaneseResultToCard(record) {
    if (!record) return null;
    const id = record.id ?? record.card_id;
    let card = id !== undefined ? state.cardById.get(String(id)) : null;
    const info = japaneseInfoFromRecord(record);
    if (!card && info?.en_name) card = state.cardByName.get(normalizeText(info.en_name)) || null;
    if (card) applyJapaneseInfo(card, record);
    return card;
  }

  async function searchJapaneseCards(query) {
    const q = String(query || '').trim();
    if (!q) return [];
    try {
      const json = await fetchJsonWithTimeout(`${JP_SEARCH_URL}${encodeURIComponent(q)}`);
      return Array.isArray(json?.result) ? json.result : [];
    } catch {
      return [];
    }
  }

  async function resolveCardAsync(name) {
    const local = fuzzyFindCard(name);
    if (local && (!looksJapanese(name) || cardMatchesName(local, name))) return local;

    const results = await searchJapaneseCards(name);
    if (!results.length) return local;
    const target = normalizeText(name);
    let best = null;
    let bestScore = -1;
    for (const result of results) {
      const card = mapJapaneseResultToCard(result);
      if (!card) continue;
      const info = japaneseInfoFromRecord(result) || {};
      const names = [info.jp_name, info.jp_ruby, info.en_name, card.name].filter(Boolean).map(normalizeText);
      let score = 0;
      if (names.includes(target)) score = 200;
      else if (names.some(n => n.startsWith(target))) score = 140;
      else if (names.some(n => n.includes(target))) score = 100;
      if (score > bestScore) { bestScore = score; best = card; }
    }
    if (best) {
      rebuildJapaneseIndex();
      saveJapaneseCache();
      return best;
    }
    return local;
  }

  function cardMatchesName(card, name) {
    const target = normalizeText(name);
    return [card?.name, card?.jp_name, card?.jp_ruby].filter(Boolean).some(v => normalizeText(v) === target);
  }

  async function resolveThemeAsync(input) {
    const raw = String(input || '').trim();
    if (!raw) return '';

    const rawNorm = normalizeText(raw);
    for (const [en, jp] of Object.entries(JP_ARCHETYPE_NAMES)) {
      if (normalizeText(jp) === rawNorm) return en;
    }
    for (const [jp, en] of Object.entries(JP_ARCHETYPE_ALIASES)) {
      if (normalizeText(jp) === rawNorm) return en;
    }

    const exact = state.archetypes.find(a => normalizeText(a) === rawNorm);
    if (exact) return exact;
    const partial = state.archetypes
      .map(a => ({ a, score: normalizeText(a).includes(rawNorm) ? 100 - Math.abs(a.length - raw.length) : -1 }))
      .sort((x, y) => y.score - x.score)[0];
    if (partial && partial.score >= 60) return partial.a;

    const results = await searchJapaneseCards(raw);
    if (!results.length) return raw;

    const scores = new Map();
    for (const result of results) {
      const card = mapJapaneseResultToCard(result);
      if (!card?.archetype) continue;
      const info = japaneseInfoFromRecord(result) || {};
      const candidates = [info.jp_name, info.jp_ruby].filter(Boolean).map(normalizeText);
      let score = 1;
      if (candidates.some(n => n === rawNorm)) score += 20;
      if (candidates.some(n => n.startsWith(rawNorm))) score += 10;
      if (candidates.some(n => n.includes(rawNorm))) score += 6;
      scores.set(card.archetype, (scores.get(card.archetype) || 0) + score);
    }
    rebuildJapaneseIndex();
    saveJapaneseCache();
    return [...scores.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || raw;
  }

  async function localizeCards(cards) {
    const unique = [...new Map(cards.filter(Boolean).map(c => [String(c.id), c])).values()];
    const missing = unique.filter(card => !card.jp_name);
    if (!missing.length) return;

    for (let i = 0; i < missing.length; i += 90) {
      const chunk = missing.slice(i, i + 90);
      let batchWorked = false;
      try {
        const json = await fetchJsonWithTimeout(JP_CARDSET_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ids: chunk.map(c => Number(c.id)) })
        }, 12000);
        for (const card of chunk) {
          const rec = json?.[String(card.id)] || json?.[card.id];
          if (rec) applyJapaneseInfo(card, rec);
        }
        batchWorked = true;
      } catch {
        batchWorked = false;
      }

      if (!batchWorked) {
        for (let j = 0; j < chunk.length; j += 6) {
          const group = chunk.slice(j, j + 6);
          await Promise.all(group.map(async card => {
            try {
              const rec = await fetchJsonWithTimeout(`${JP_CARD_URL}${encodeURIComponent(card.id)}`, {}, 7000);
              applyJapaneseInfo(card, rec);
            } catch {}
          }));
        }
      }
    }
    rebuildJapaneseIndex();
    await saveJapaneseCache();
  }

  function isExtraDeckCard(card) {
    const f = String(card.frameType || '').toLowerCase();
    return ['fusion', 'synchro', 'xyz', 'link'].includes(f) || /Fusion|Synchro|XYZ|Link Monster/i.test(card.type || '');
  }

  function normalizeMdRarity(value) {
    const raw = String(value || '').trim().toUpperCase().replace(/[._-]+/g, ' ').replace(/\s+/g, ' ');
    if (!raw) return '';
    if (raw === 'N' || raw === 'NORMAL' || raw === 'NORMAL RARE' || raw === 'COMMON') return 'N';
    if (raw === 'R' || raw === 'RARE') return 'R';
    if (raw === 'SR' || raw === 'SUPER RARE' || raw === 'SUPERRARE') return 'SR';
    if (raw === 'UR' || raw === 'ULTRA RARE' || raw === 'ULTRARARE') return 'UR';
    return ['N', 'R', 'SR', 'UR'].includes(raw) ? raw : '';
  }

  function getMdRarity(card) {
    if (!card) return '';
    const direct = normalizeMdRarity(card.md_rarity);
    if (direct) return direct;
    const misc = Array.isArray(card.misc_info) ? card.misc_info.find(x => x && x.md_rarity) : null;
    return normalizeMdRarity(misc && misc.md_rarity);
  }

  function mdRarityLabel(card, { compact = false } = {}) {
    const r = getMdRarity(card);
    if (!r) return compact ? 'MD -' : 'Master Duel: 不明';
    const ja = { N: 'ノーマル', R: 'レア', SR: 'スーパーレア', UR: 'ウルトラレア' }[r] || '';
    return compact ? `MD ${r}` : `Master Duel: ${r}（${ja}）`;
  }

  function rarityRank(card) {
    const r = getMdRarity(card);
    return { N: 0, R: 1, SR: 2, UR: 3 }[r] ?? 2;
  }

  function getLimit(card) {
    const limits = state.regulation.limits || {};
    const byId = limits[String(card.id)];
    if (byId !== undefined) return clampLimit(byId);
    const byName = limits[card.name];
    if (byName !== undefined) return clampLimit(byName);
    return 3;
  }

  function clampLimit(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return 3;
    return Math.max(0, Math.min(3, Math.floor(n)));
  }

  function reasonFor(card, theme) {
    const d = String(card.desc || '').toLowerCase();
    const name = String(card.name || '').toLowerCase();
    const themeLower = String(theme || '').toLowerCase();
    const tags = [];
    if (card.archetype === theme || name.includes(themeLower) || d.includes(themeLower)) tags.push('テーマ連携');
    if (/add 1|from your deck to your hand|search/i.test(d)) tags.push('初動/サーチ');
    if (/special summon this card|special summon 1/i.test(d)) tags.push('展開補助');
    if (/draw 1|draw 2/i.test(d)) tags.push('ドロー');
    if (/negate/i.test(d)) tags.push('妨害');
    if (/banish|destroy|return .* hand|shuffle .* deck/i.test(d)) tags.push('除去');
    if (/quick effect/i.test(d)) tags.push('速攻性');
    return tags.slice(0, 3).join(' / ') || 'デッキ枠調整';
  }

  function matchingJokeRules(concept) {
    const c = normalizeText(concept);
    if (!c) return [];
    return JOKE_KEYWORD_RULES.filter(rule => rule.keys.some(key => {
      const k = normalizeText(key);
      return c.includes(k) || k.includes(c);
    }));
  }

  function inferJokeType(concept, selected) {
    if (selected && selected !== 'auto') return selected;
    const c = normalizeText(concept);
    if (/パチンコ|大当たり|連チャン|確変/.test(c)) return 'pachinko';
    if (/パチスロ|スロット|ジャックポット/.test(c)) return 'slot';
    if (/特殊勝利|勝利条件|エクゾディア|win the duel|exodia/.test(c)) return 'altwin';
    if (/ワンキル|一撃必殺|otk/.test(c)) return 'otk';
    if (/バーン|効果ダメージ/.test(c)) return 'burn';
    if (/デッキ破壊|デッキデス|mill/.test(c)) return 'mill';
    if (/ロック|封殺|行動制限/.test(c)) return 'lock';
    if (/通常モンスター|バニラ/.test(c)) return 'vanilla';
    if (/レベル\s*1|レベル1|低レベル/.test(c)) return 'levelone';
    if (/高打点|脳筋|パワー/.test(c)) return 'muscle';
    if (/自爆|自傷|lp極限/.test(c)) return 'selfburn';
    if (/コイン|サイコロ|ダイス|運試し|coin|dice/.test(c)) return 'gamble';
    if (/レベル\s*\d+|だけ|縛り|攻撃力\s*\d+|守備力\s*\d+/.test(c)) return 'restriction';
    if (/海馬|遊戯|城之内|十代|遊星|ジャック|カイト|遊馬|遊矢|遊作|原作|キャラ/.test(c)) return 'character';
    if (/カオス|ごちゃまぜ|闇鍋/.test(c)) return 'chaos';
    return 'romance';
  }

  function characterThemeFor(concept) {
    const target = normalizeText(concept);
    if (!target) return '';
    for (const [name, theme] of Object.entries(CHARACTER_THEME_ALIASES)) {
      if (target.includes(normalizeText(name))) return theme;
    }
    return '';
  }

  function jokeLevelConfig(level, targetMain) {
    const scale = targetMain / 40;
    const base = {
      practical: { concept: 17, staples: 10 },
      balanced: { concept: 24, staples: 6 },
      allin: { concept: 31, staples: 2 }
    }[level] || { concept: 24, staples: 6 };
    return {
      conceptTarget: Math.min(targetMain, Math.max(10, Math.round(base.concept * scale))),
      stapleCap: Math.max(0, Math.round(base.staples * scale))
    };
  }

  async function resolveJokeSeeds(concept) {
    const q = String(concept || '').trim();
    if (!q) return [];
    const found = new Map();

    const local = fuzzyFindCard(q);
    if (local && cardMatchesName(local, q)) found.set(String(local.id), local);

    const results = await searchJapaneseCards(q);
    for (const result of results.slice(0, 24)) {
      const card = mapJapaneseResultToCard(result);
      if (card) found.set(String(card.id), card);
    }

    const qNorm = normalizeText(q);
    if (!looksJapanese(q)) {
      for (const card of state.cards) {
        const hay = normalizeText(`${card.name || ''} ${card.archetype || ''}`);
        if (hay.includes(qNorm)) found.set(String(card.id), card);
        if (found.size >= 24) break;
      }
    }

    rebuildJapaneseIndex();
    saveJapaneseCache();
    return [...found.values()].slice(0, 24);
  }

  function scoreJokeCard(card, concept, jokeType, seeds, theme) {
    const d = String(card.desc || '');
    const n = String(card.name || '');
    const a = String(card.archetype || '');
    const c = normalizeText(concept);
    let score = 0;

    if (c && !looksJapanese(concept)) {
      const raw = normalizeText(`${n} ${a} ${d}`);
      if (raw.includes(c)) score += 115;
    }

    const rules = matchingJokeRules(concept);
    for (const rule of rules) {
      if (rule.test(card)) score += 125;
    }

    const levelMatch = String(concept || '').match(/(?:レベル|lv\.?)[^0-9]*(\d{1,2})/i);
    if (levelMatch) {
      const wanted = Number(levelMatch[1]);
      const lv = Number(card.level || 0);
      score += lv === wanted ? 120 : -18;
    }

    const rankMatch = String(concept || '').match(/(?:ランク|rank)[^0-9]*(\d{1,2})/i);
    if (rankMatch) {
      const wanted = Number(rankMatch[1]);
      const rank = Number(card.level || card.rank || 0);
      score += rank === wanted && /XYZ/i.test(String(card.type || '')) ? 120 : -10;
    }

    if (/モンスターだけ|モンスター縛り/.test(String(concept || ''))) score += /Monster/i.test(String(card.type || '')) ? 80 : -80;
    if (/魔法だけ|魔法縛り/.test(String(concept || ''))) score += /Spell Card/i.test(String(card.type || '')) ? 90 : -80;
    if (/罠だけ|罠縛り/.test(String(concept || ''))) score += /Trap Card/i.test(String(card.type || '')) ? 90 : -80;

    const seedIds = new Set((seeds || []).map(x => String(x.id)));
    if (seedIds.has(String(card.id))) score += 170;
    for (const seed of seeds || []) {
      if (seed.archetype && card.archetype && seed.archetype === card.archetype) score += 58;
      if (seed.race && card.race && seed.race === card.race) score += 5;
      if (seed.attribute && card.attribute && seed.attribute === card.attribute) score += 4;
      if (Number(seed.level || 0) && Number(seed.level || 0) === Number(card.level || 0)) score += 3;
    }

    if (theme && card.archetype === theme) score += jokeType === 'character' ? 85 : 28;

    if (jokeType === 'altwin') {
      if (/win the duel/i.test(d)) score += 150;
      if (/exodia|forbidden one/i.test(`${n} ${d}`)) score += 100;
      if (/draw 1|draw 2|from your deck to your hand|add 1/i.test(d)) score += 13;
    } else if (jokeType === 'pachinko') {
      if (/coin toss|toss a coin|six-sided die|roll a die|die result|number of heads|number rolled/i.test(d)) score += 170;
      if (/draw 1|draw 2|excavate|random|inflict .*damage|gain .*lp/i.test(d)) score += 28;
      if (/once per turn|each time|repeat/i.test(d)) score += 12;
    } else if (jokeType === 'slot') {
      if (/coin toss|toss a coin|six-sided die|roll a die|die result|number of heads|number rolled/i.test(d)) score += 185;
      if (/draw 1|draw 2|random/i.test(d)) score += 18;
    } else if (jokeType === 'gamble') {
      if (/coin toss|toss a coin|six-sided die|roll a die|die result/i.test(d)) score += 145;
    } else if (jokeType === 'otk') {
      if (Number(card.atk || 0) >= 3000) score += 55;
      if (/attack directly|second attack|attack twice|double .*battle damage|gains? .*atk/i.test(d)) score += 85;
      if (/destroy|banish|negate/i.test(d)) score += 10;
    } else if (jokeType === 'burn') {
      if (/inflict .*damage|effect damage/i.test(d)) score += 155;
      if (/each time|once per turn/i.test(d)) score += 12;
    } else if (jokeType === 'mill') {
      if (/top .*deck.*(?:gy|graveyard)|send .* from the top of .*deck|deck to the gy|banish .* from .*deck/i.test(d)) score += 155;
    } else if (jokeType === 'lock') {
      if (/cannot (?:activate|attack|summon)|neither player can|your opponent cannot|skip .* phase|negate .* activation/i.test(d)) score += 135;
    } else if (jokeType === 'vanilla') {
      if (/Normal Monster/i.test(String(card.type || ''))) score += 155;
      if (/normal monster/i.test(d)) score += 35;
    } else if (jokeType === 'levelone') {
      if (Number(card.level || 0) === 1) score += 155;
      if (/level 1/i.test(d)) score += 35;
    } else if (jokeType === 'muscle') {
      score += Math.max(0, Math.min(90, Math.floor((Number(card.atk || 0) - 2200) / 20)));
      if (/gains? .*atk|double .*atk|original atk/i.test(d)) score += 35;
    } else if (jokeType === 'selfburn') {
      if (/pay .*lp|halve your lp|take .*damage|inflict .*damage to you|your lp becomes/i.test(d)) score += 150;
      if (/if your lp|while your lp|lp is lower/i.test(d)) score += 30;
    } else if (jokeType === 'romance') {
      const level = Number(card.level || card.rank || 0);
      const atk = Number(card.atk || 0);
      if (level >= 8) score += 18;
      if (atk >= 3000) score += 16;
      if (isExtraDeckCard(card)) score += 12;
      if (/must be .*summoned|cannot be normal summoned|special summon/i.test(d)) score += 10;
    } else if (jokeType === 'chaos') {
      score += (Number(card.id || 0) % 19);
      if (/coin toss|six-sided die|both players|switch control|original atk|original attack/i.test(d)) score += 22;
    }

    if (/from your deck to your hand|add 1 .* from your deck|special summon 1|special summon this card/i.test(d)) score += 9;
    return score;
  }

  function reasonForJoke(card, theme, concept, jokeType, seeds) {
    const d = String(card.desc || '');
    const tags = [];
    const seedIds = new Set((seeds || []).map(x => String(x.id)));
    if (seedIds.has(String(card.id))) tags.push('ネタ主役');
    if (matchingJokeRules(concept).some(rule => rule.test(card))) tags.push('ネタ軸');
    if (jokeType === 'altwin' && /win the duel|exodia|forbidden one/i.test(`${card.name || ''} ${d}`)) tags.push('特殊勝利');
    if (jokeType === 'pachinko' && /coin toss|six-sided die|roll a die|die result|draw [12]|excavate|random|inflict .*damage/i.test(d)) tags.push('パチンコ軸');
    if (jokeType === 'slot' && /coin toss|six-sided die|roll a die|die result|number of heads|number rolled/i.test(d)) tags.push('パチスロ軸');
    if (jokeType === 'gamble' && /coin toss|six-sided die|roll a die|die result/i.test(d)) tags.push('運試し');
    if (jokeType === 'otk' && (Number(card.atk || 0) >= 3000 || /attack directly|second attack|attack twice|double .*battle damage/i.test(d))) tags.push('一撃枠');
    if (jokeType === 'burn' && /inflict .*damage|effect damage/i.test(d)) tags.push('バーン');
    if (jokeType === 'mill' && /top .*deck|deck to the gy|from .*deck/i.test(d)) tags.push('デッキ破壊');
    if (jokeType === 'lock' && /cannot |neither player can|your opponent cannot|skip .* phase/i.test(d)) tags.push('ロック');
    if (jokeType === 'vanilla' && /Normal Monster/i.test(String(card.type || ''))) tags.push('通常モンスター');
    if (jokeType === 'levelone' && Number(card.level || 0) === 1) tags.push('レベル1');
    if (jokeType === 'muscle' && Number(card.atk || 0) >= 3000) tags.push('高打点');
    if (jokeType === 'selfburn' && /pay .*lp|halve your lp|take .*damage|your lp becomes/i.test(d)) tags.push('LP極限');
    if (jokeType === 'romance' && (Number(card.atk || 0) >= 3000 || Number(card.level || 0) >= 8)) tags.push('ロマン枠');
    if (theme && card.archetype === theme) tags.push('テーマ連携');
    if (/add 1|from your deck to your hand|special summon/i.test(d)) tags.push('成立補助');
    return tags.slice(0, 3).join(' / ') || 'ネタ成立補助';
  }

  function recommendedJokeCopies(card, score, jokeType, jokeLevel, seeds) {
    if (isExtraDeckCard(card)) return score >= 220 ? 2 : 1;
    if (jokeType === 'chaos') return 1;
    if (/exodia|forbidden one/i.test(String(card.name || ''))) return 1;
    if (/win the duel/i.test(String(card.desc || ''))) return 1;
    const isSeed = (seeds || []).some(x => String(x.id) === String(card.id));
    if (isSeed && score >= 150) return jokeLevel === 'allin' ? 3 : 2;
    if (score >= 180) return jokeLevel === 'allin' ? 3 : 2;
    if (score >= 100) return 2;
    return 1;
  }

  function scoreThemeCard(card, theme, profile, lowRarity) {
    const d = String(card.desc || '').toLowerCase();
    const n = String(card.name || '').toLowerCase();
    const t = String(theme || '').toLowerCase();
    let score = 0;

    if (card.archetype === theme) score += 110;
    if (t && n.includes(t)) score += 30;
    if (t && d.includes(t)) score += 42;

    if (/from your deck to your hand|add 1 .* from your deck|search/i.test(d)) score += 28;
    if (/special summon this card|special summon 1/i.test(d)) score += 22;
    if (/send 1 .* from your deck/i.test(d)) score += 14;
    if (/draw 1|draw 2/i.test(d)) score += 14;
    if (/negate/i.test(d)) score += profile === 'first' ? 25 : 16;
    if (/destroy|banish|return .* hand|shuffle .* deck/i.test(d)) score += profile === 'second' ? 24 : 14;
    if (/quick effect/i.test(d)) score += 10;

    if (/Normal Monster/i.test(card.type || '')) score -= 18;
    if (Number(card.level || card.rank || 0) >= 7 && !/special summon/i.test(d)) score -= 16;
    if (/cannot special summon|you cannot special summon/i.test(d)) score -= 7;

    if (profile === 'budget' || lowRarity) score -= rarityRank(card) * 12;
    return score;
  }

  function recommendedCopies(card, score, theme) {
    const d = String(card.desc || '').toLowerCase();
    const level = Number(card.level || card.rank || 0);
    if (isExtraDeckCard(card)) return score > 135 ? 2 : 1;
    if (/Field Spell/i.test(card.type || '') && score > 120) return 2;
    if (/Trap Card/i.test(card.type || '')) return score > 135 ? 3 : 2;
    if (level >= 8 && !/special summon this card/i.test(d)) return 1;
    if (/add 1|from your deck to your hand|special summon this card/i.test(d) && score > 120) return 3;
    if (card.archetype === theme && score > 125) return 2;
    return 1;
  }

  function fuzzyFindCard(name) {
    const target = normalizeText(name);
    if (!target) return null;
    if (state.cardByName.has(target)) return state.cardByName.get(target);
    if (state.cardByJpName.has(target)) return state.cardByJpName.get(target);

    let best = null;
    let bestScore = -Infinity;
    for (const card of state.cards) {
      const names = [card.name, card.jp_name, card.jp_ruby].filter(Boolean).map(normalizeText);
      let cardScore = -Infinity;
      for (const cn of names) {
        let score = -Infinity;
        if (cn === target) score = 220;
        else if (cn.startsWith(target)) score = 145 - Math.abs(cn.length - target.length);
        else if (cn.includes(target)) score = 115 - Math.abs(cn.length - target.length);
        else if (target.includes(cn)) score = 80 - Math.abs(cn.length - target.length);
        if (score > cardScore) cardScore = score;
      }
      if (cardScore > bestScore) {
        bestScore = cardScore;
        best = card;
      }
    }
    return bestScore >= 45 ? best : null;
  }

  function resolveTheme(input) {
    const raw = String(input || '').trim();
    if (!raw) return '';
    const mapped = Object.entries(JP_ARCHETYPE_NAMES).find(([, jp]) => normalizeText(jp) === normalizeText(raw));
    if (mapped) return mapped[0];
    const alias = JP_ARCHETYPE_ALIASES[raw];
    if (alias) return alias;
    const lower = raw.toLowerCase();
    const exact = state.archetypes.find(a => a.toLowerCase() === lower);
    if (exact) return exact;
    const partial = state.archetypes
      .map(a => ({ a, score: a.toLowerCase().includes(lower) ? 100 - Math.abs(a.length - raw.length) : -1 }))
      .sort((x, y) => y.score - x.score)[0];
    return partial && partial.score >= 60 ? partial.a : raw;
  }

  function addEntry(map, card, qty, reason) {
    if (!card || qty <= 0) return 0;
    const limit = getLimit(card);
    const current = map.get(card.id)?.qty || 0;
    const actual = Math.max(0, Math.min(qty, limit - current));
    if (actual <= 0) return 0;
    if (map.has(card.id)) {
      map.get(card.id).qty += actual;
    } else {
      map.set(card.id, { card, qty: actual, reason });
    }
    return actual;
  }

  function countEntries(map) {
    let n = 0;
    for (const e of map.values()) n += e.qty;
    return n;
  }

  async function buildDeck() {
    if (!state.cards.length) {
      setHint('カードDBを先に同期してください。', 'error');
      return;
    }

    const buildBtn = $('buildBtn');
    buildBtn.disabled = true;
    const selectedTheme = String($('themeSelect')?.value || '').trim();
    const rawTheme = selectedThemeLabel();
    try {
      const profile = $('profileSelect').value;
      const jokeMode = profile === 'joke';
      const jokeConcept = jokeMode ? String($('jokeConcept')?.value || '').trim() : '';
      const selectedJokeType = jokeMode ? ($('jokeType')?.value || 'auto') : '';
      const jokeType = jokeMode ? inferJokeType(jokeConcept, selectedJokeType) : '';
      const jokeLevel = jokeMode ? ($('jokeLevel')?.value || 'balanced') : '';
      setHint(jokeMode ? 'ネタの主役・関連カードを探しています…' : '選択したテーマをもとに構築しています…', 'notice');
      let theme = selectedTheme;
      if (jokeMode && !theme && jokeType === 'character') theme = characterThemeFor(jokeConcept);
      const targetMain = Math.max(40, Math.min(60, Number($('mainSize').value) || 40));
      const targetExtra = Math.max(0, Math.min(15, Number($('extraSize').value) || 15));
      const density = $('themeDensity').value;
      const lowRarity = $('favorLowRarity').checked;
      const scoreProfile = jokeMode ? 'balanced' : profile;
      const mustNames = linesToNames($('mustInput').value);
      const excludeNames = linesToNames($('excludeInput').value);
      const excludes = new Set(excludeNames.map(normalizeText));
      const excludeIds = new Set();

      const hasJokeDirection = jokeMode && (jokeConcept || (selectedJokeType && selectedJokeType !== 'auto'));
      if (!theme && !mustNames.length && !hasJokeDirection) {
        setHint(jokeMode ? 'ネタの方向性を選ぶか、ネタ内容・テーマ・必須カードのいずれかを指定してください。' : 'テーマ、または必ず入れたいカードを指定してください。', 'error');
        return;
      }

      for (const name of excludeNames) {
        const card = await resolveCardAsync(name);
        if (card) excludeIds.add(String(card.id));
      }

      const main = new Map();
      const extra = new Map();
      const warnings = [];

      const canUse = (card) => {
        if (!card || getLimit(card) <= 0 || excludeIds.has(String(card.id))) return false;
        const cardNames = [card.name, card.jp_name, card.jp_ruby].filter(Boolean).map(normalizeText);
        return !cardNames.some(n => excludes.has(n));
      };

      // 必須カードを先に追加。日本語カード名にも対応。
      for (const name of mustNames) {
        const card = await resolveCardAsync(name);
        if (!card) {
          warnings.push(`必須カード「${name}」がDBで見つかりませんでした。`);
          continue;
        }
        if (!canUse(card)) {
          warnings.push(`必須カード「${displayName(card)}」は除外または禁止設定です。`);
          continue;
        }
        const dest = isExtraDeckCard(card) ? extra : main;
        addEntry(dest, card, 1, jokeMode ? 'ユーザー指定 / ネタ主役' : 'ユーザー指定');
      }

      const jokeSeeds = jokeMode ? await resolveJokeSeeds(jokeConcept) : [];
      const jokeCandidates = jokeMode ? state.cards
        .filter(canUse)
        .map(card => ({ card, score: scoreJokeCard(card, jokeConcept, jokeType, jokeSeeds, theme) }))
        .filter(x => x.score >= 24)
        .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card)) : [];

      if (jokeMode && jokeConcept && !jokeCandidates.length) {
        warnings.push(`ネタ内容「${jokeConcept}」に強く一致するカードが見つからなかったため、テーマ・主役カード中心で補完します。`);
      }

      const themeCandidates = state.cards
        .filter(canUse)
        .filter(card => {
          if (!theme) return false;
          const t = theme.toLowerCase();
          return card.archetype === theme || String(card.name || '').toLowerCase().includes(t) || String(card.desc || '').toLowerCase().includes(t);
        })
        .map(card => ({ card, score: scoreThemeCard(card, theme, scoreProfile, lowRarity) }))
        .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card));

      if (theme && !themeCandidates.length) {
        if (jokeMode && (jokeConcept || jokeCandidates.length)) {
          warnings.push(`テーマ「${rawTheme || theme}」は認識できなかったため、ネタ内容を中心に構築します。`);
          theme = '';
        } else {
          setHint(`テーマ「${rawTheme || theme}」をカードDB上で認識できませんでした。別の表記で入力してください。`, 'error');
          state.deck = null;
          return;
        }
      }

      const jokeConfig = jokeMode ? jokeLevelConfig(jokeLevel, targetMain) : { conceptTarget: 0, stapleCap: Infinity };

      if (jokeMode) {
        for (const item of jokeCandidates) {
          if (countEntries(main) >= jokeConfig.conceptTarget) break;
          if (isExtraDeckCard(item.card)) continue;
          const left = jokeConfig.conceptTarget - countEntries(main);
          const qty = Math.min(left, recommendedJokeCopies(item.card, item.score, jokeType, jokeLevel, jokeSeeds));
          addEntry(main, item.card, qty, reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds));
        }
      }

      const densityTarget = density === 'high' ? 31 : density === 'low' ? 21 : 26;
      const normalThemeTarget = Math.min(targetMain, Math.max(16, Math.round(densityTarget * (targetMain / 40))));
      const jokeThemeFactor = jokeType === 'character' ? 1 : (density === 'high' ? 0.72 : density === 'low' ? 0.42 : 0.56);
      const themeMainTarget = theme ? (jokeMode
        ? Math.min(targetMain, Math.max(8, Math.round(normalThemeTarget * jokeThemeFactor)))
        : normalThemeTarget) : 0;

      const countThemeCards = () => {
        if (!theme) return 0;
        let total = 0;
        for (const e of main.values()) {
          const c = e.card;
          const t = String(theme).toLowerCase();
          if (c.archetype === theme || String(c.name || '').toLowerCase().includes(t) || String(c.desc || '').toLowerCase().includes(t)) total += e.qty;
        }
        return total;
      };

      for (const item of themeCandidates) {
        if (countEntries(main) >= targetMain || countThemeCards() >= themeMainTarget) break;
        if (isExtraDeckCard(item.card)) continue;
        const left = Math.min(targetMain - countEntries(main), themeMainTarget - countThemeCards());
        const qty = Math.min(left, recommendedCopies(item.card, item.score, theme));
        addEntry(main, item.card, qty, jokeMode ? reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds) : reasonFor(item.card, theme));
      }

      const staplePool = jokeMode ? STAPLES.balanced : (STAPLES[profile] || STAPLES.balanced);
      let stapleAdded = 0;
      for (const [name, desired] of staplePool) {
        if (countEntries(main) >= targetMain) break;
        if (jokeMode && stapleAdded >= jokeConfig.stapleCap) break;
        const card = fuzzyFindCard(name);
        if (!canUse(card) || isExtraDeckCard(card)) continue;
        if ((profile === 'budget' || lowRarity) && rarityRank(card) >= 3 && name !== 'Ash Blossom & Joyous Spring') continue;
        const left = targetMain - countEntries(main);
        const wanted = jokeMode ? Math.min(desired, jokeConfig.stapleCap - stapleAdded) : desired;
        const added = addEntry(main, card, Math.min(left, wanted), jokeMode ? '実戦補助 / 汎用札' : '汎用札');
        stapleAdded += added;
      }

      const fallback = state.cards
        .filter(canUse)
        .filter(card => !isExtraDeckCard(card))
        .map(card => {
          let score = scoreThemeCard(card, theme, scoreProfile, lowRarity);
          const d = String(card.desc || '').toLowerCase();
          const jokeScore = jokeMode ? scoreJokeCard(card, jokeConcept, jokeType, jokeSeeds, theme) : 0;
          if (jokeMode) score = Math.max(score * 0.65, jokeScore);
          if (/negate/i.test(d)) score += jokeMode ? 5 : 14;
          if (/draw 1|draw 2/i.test(d)) score += jokeMode ? 8 : 10;
          if (/destroy|banish/i.test(d)) score += jokeMode ? 4 : 8;
          if (profile === 'budget' || lowRarity) score -= rarityRank(card) * 10;
          return { card, score, jokeScore };
        })
        .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card));

      for (const item of fallback) {
        if (countEntries(main) >= targetMain) break;
        if (main.has(item.card.id)) continue;
        if (!jokeMode && item.score < 12 && themeCandidates.length > 8) continue;
        if (jokeMode && item.score < 8 && (jokeCandidates.length > 5 || themeCandidates.length > 8)) continue;
        const reason = jokeMode && item.jokeScore >= 24
          ? reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds)
          : reasonFor(item.card, theme);
        addEntry(main, item.card, 1, reason);
      }

      if (countEntries(main) < targetMain) {
        const emergency = state.cards
          .filter(canUse)
          .filter(c => !isExtraDeckCard(c) && !main.has(c.id))
          .map(card => ({ card, score: jokeMode ? scoreJokeCard(card, jokeConcept, jokeType, jokeSeeds, theme) : -rarityRank(card) }))
          .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card));
        for (const item of emergency) {
          if (countEntries(main) >= targetMain) break;
          addEntry(main, item.card, 1, jokeMode ? 'ネタ成立補助 / 枚数調整' : '枚数調整');
        }
      }

      if (jokeMode) {
        const jokeExtraTarget = Math.min(targetExtra, { practical: 6, balanced: 10, allin: 15 }[jokeLevel] || 10);
        for (const item of jokeCandidates) {
          if (countEntries(extra) >= jokeExtraTarget) break;
          if (!isExtraDeckCard(item.card)) continue;
          const left = jokeExtraTarget - countEntries(extra);
          addEntry(extra, item.card, Math.min(left, recommendedJokeCopies(item.card, item.score, jokeType, jokeLevel, jokeSeeds)), reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds));
        }
      }

      const extraTheme = themeCandidates.filter(x => isExtraDeckCard(x.card));
      for (const item of extraTheme) {
        if (countEntries(extra) >= targetExtra) break;
        const left = targetExtra - countEntries(extra);
        addEntry(extra, item.card, Math.min(left, recommendedCopies(item.card, item.score, theme)), jokeMode ? reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds) : reasonFor(item.card, theme));
      }

      for (const name of GENERIC_EXTRA) {
        if (countEntries(extra) >= targetExtra) break;
        const card = fuzzyFindCard(name);
        if (!canUse(card) || !isExtraDeckCard(card) || extra.has(card.id)) continue;
        if ((profile === 'budget' || lowRarity) && rarityRank(card) >= 3) continue;
        addEntry(extra, card, 1, jokeMode ? '実戦補助 / 汎用EX' : '汎用EX候補');
      }

      if (countEntries(extra) < targetExtra) {
        const allExtra = state.cards
          .filter(canUse)
          .filter(isExtraDeckCard)
          .filter(c => !extra.has(c.id))
          .map(card => {
            const themeScore = scoreThemeCard(card, theme, scoreProfile, lowRarity);
            const jokeScore = jokeMode ? scoreJokeCard(card, jokeConcept, jokeType, jokeSeeds, theme) : 0;
            return { card, score: jokeMode ? Math.max(themeScore, jokeScore) : themeScore, jokeScore };
          })
          .sort((a, b) => b.score - a.score || rarityRank(a.card) - rarityRank(b.card));
        for (const item of allExtra) {
          if (countEntries(extra) >= targetExtra) break;
          if (!jokeMode && item.score < 1 && extraTheme.length) break;
          addEntry(extra, item.card, 1, jokeMode && item.jokeScore >= 24 ? reasonForJoke(item.card, theme, jokeConcept, jokeType, jokeSeeds) : reasonFor(item.card, theme));
        }
      }

      if (countEntries(main) < 40) warnings.push(`メインデッキが${countEntries(main)}枚です。40枚以上必要です。`);
      if (!Object.keys(state.regulation.limits || {}).length) warnings.push('Master Duel専用の禁止・制限設定が未登録です。ゲーム内の最新レギュレーションを確認してください。');

      const deckLabel = rawTheme || jokeConcept || theme || (jokeMode ? (JOKE_TYPE_LABELS[jokeType] || 'ネタ') : 'カスタム');
      state.deck = {
        name: jokeMode ? `${deckLabel} ネタデッキ` : (rawTheme ? `${rawTheme} 自動構築` : 'カスタム自動構築'),
        theme,
        themeLabel: rawTheme || theme,
        profile,
        jokeMode,
        jokeConcept,
        jokeType,
        jokeLevel,
        jokeRelatedIds: jokeMode ? jokeCandidates.filter(x => x.score >= 60).map(x => String(x.card.id)) : [],
        generated_at: new Date().toISOString(),
        main: Array.from(main.values()),
        extra: Array.from(extra.values()),
        warnings
      };

      setHint('日本語カード名を取得しています…', 'notice');
      await localizeCards([...state.deck.main, ...state.deck.extra].map(x => x.card));
      await cacheSet(LAST_DECK_KEY, state.deck);
      renderDeck();
      const resolvedNote = ''; // 内部の英語アーキタイプ名は画面に出さない
      setHint(jokeMode
        ? `ネタデッキの自動構築が完了しました${resolvedNote}。ネタ度「${JOKE_LEVEL_LABELS[jokeLevel] || jokeLevel}」で生成しています。`
        : `自動構築が完了しました${resolvedNote}。カード名は日本語入力・日本語表示に対応し、各カードにMaster Duelレアリティを表示します。`, 'ok');
    } catch (err) {
      setHint(`自動構築中にエラーが発生しました: ${err.message}`, 'error');
    } finally {
      buildBtn.disabled = false;
    }
  }

  function roleCardNames(entries, regex, limit = 4) {
    const out = [];
    for (const entry of entries || []) {
      const card = entry.card;
      const hay = `${card.name || ''} ${card.desc || ''} ${card.type || ''}`;
      if (!regex.test(hay)) continue;
      const name = displayName(card);
      if (!out.includes(name)) out.push(name);
      if (out.length >= limit) break;
    }
    return out;
  }

  function strongestFinishers(deck, limit = 4) {
    return [...(deck.extra || []), ...(deck.main || [])]
      .filter(x => Number(x.card?.atk || 0) >= 2400)
      .sort((a, b) => Number(b.card.atk || 0) - Number(a.card.atk || 0))
      .map(x => displayName(x.card))
      .filter((name, i, arr) => arr.indexOf(name) === i)
      .slice(0, limit);
  }

  function jokeStrategyText(type) {
    const map = {
      pachinko: 'コイントス・サイコロ・ランダム処理・ドロー・効果ダメージなど、結果が連鎖して「当たり」を伸ばせるカードを優先しています。1回の成功だけに依存せず、複数回抽選できる盤面を目指します。',
      slot: 'コイントスやサイコロ判定を何度も行えるカードを多めにし、結果の振れ幅そのものを勝ち筋にしています。判定回数を増やせるカードを先に確保します。',
      gamble: 'コイン・サイコロなど運要素を主役にしつつ、完全に事故らないよう最低限の初動と汎用札を残しています。',
      altwin: '特殊勝利条件へ到達するカードと、必要札を集めるサーチ・ドローを優先しています。通常の戦闘勝利は補助ルートです。',
      otk: '高打点・直接攻撃・連続攻撃・打点上昇を優先し、相手の盤面を崩したターンにライフを取り切る構成です。',
      burn: '戦闘以外の効果ダメージを積み重ねるカードを優先し、相手のライフを継続的に削る構成です。',
      mill: '相手デッキを墓地へ送る・除外するカードを優先し、デッキ切れやリソース枯渇を狙います。',
      lock: '相手の召喚・効果・攻撃などを制限するカードを優先し、相手の選択肢を減らして主導権を維持します。',
      vanilla: '通常モンスターそのものと、通常モンスターを支えるカードを中心にした構成です。',
      levelone: 'レベル1モンスターを中心に、低レベル同士の展開やEXデッキへの接続を狙います。',
      muscle: '高攻撃力モンスターと打点上昇を優先し、細かいアドバンテージより戦闘で押し切ることを重視します。',
      selfburn: 'LP支払い・自傷をメリットへ変えるカードを優先し、低LP状態を条件にする効果や逆転札を活用します。',
      romance: '大型エースや成立難度の高いコンボを主役にし、その着地を支える展開札を多めに採用しています。',
      character: 'キャラクターや原作イメージを優先し、テーマカードの比率を高めています。',
      chaos: 'カード同士の意外な噛み合いと派手さを優先し、1枚採用を多めにして毎回違う展開になりやすくしています。',
      restriction: '指定した縛り条件に合うカードを優先し、その条件の中で最低限デッキが動くよう補助札を追加しています。'
    };
    return map[type] || '指定したネタ内容を優先しつつ、最低限デッキとして動くよう初動・展開札・汎用札を補っています。';
  }

  function buildDeckGuide(deck) {
    const main = deck.main || [];
    const all = [...main, ...(deck.extra || [])];
    const mainCount = main.reduce((s, x) => s + x.qty, 0);
    const themeCount = deck.theme ? all.reduce((s, x) => {
      const d = String(x.card?.desc || '').toLowerCase();
      const t = String(deck.theme || '').toLowerCase();
      return s + ((x.card?.archetype === deck.theme || d.includes(t)) ? x.qty : 0);
    }, 0) : 0;

    const starters = roleCardNames(main, /from your deck to your hand|add 1 .* from your deck|search|special summon this card|special summon 1/i, 4);
    const extenders = roleCardNames(main, /special summon|send 1 .* from your deck|summon .* from your (?:hand|gy|graveyard)/i, 4);
    const disruption = roleCardNames(main, /negate|quick effect|banish|destroy|return .* hand|shuffle .* deck/i, 4);
    const draw = roleCardNames(main, /draw 1|draw 2|draw .*card/i, 3);
    const finishers = strongestFinishers(deck, 4);

    const reasons = [];
    const themeName = deck.themeLabel || themeDisplayName(deck.theme) || '指定なし';
    if (deck.theme) reasons.push(`・テーマ「${themeName}」のカードを軸にし、MAIN/EXTRAを合わせて約${themeCount}枚をテーマ連携枠として採用しています。`);
    if (deck.jokeMode) reasons.push(`・ネタ方向は「${JOKE_TYPE_LABELS[deck.jokeType] || deck.jokeType}」、ネタ度は「${JOKE_LEVEL_LABELS[deck.jokeLevel] || deck.jokeLevel}」です。${jokeStrategyText(deck.jokeType)}`);
    if (deck.profile === 'first') reasons.push('・先攻寄りのため、妨害・速攻効果・展開を優先しています。');
    else if (deck.profile === 'second') reasons.push('・後攻寄りのため、除去・盤面突破・高打点を優先しています。');
    else if (deck.profile === 'budget') reasons.push('・低レア優先のため、UR/SRを抑えながら機能が近いカードを優先しています。');
    else if (!deck.jokeMode) reasons.push('・バランス型として、テーマ札・初動・妨害・汎用札が偏りすぎないように配分しています。');
    if (starters.length) reasons.push(`・初動候補として ${starters.join(' / ')} などを確保しています。`);
    if (disruption.length) reasons.push(`・相手ターンの妨害候補として ${disruption.join(' / ')} などを採用しています。`);
    reasons.push(`・メインは${mainCount}枚にまとめ、引きたいカードへアクセスしやすい枚数を基準にしています。`);

    const play = [];
    play.push('【基本手順】');
    if (starters.length) play.push(`1. 初手では ${starters.join(' / ')} を優先し、サーチまたは特殊召喚から展開を始めます。`);
    else play.push('1. 初手では、手札から動けるカードとサーチ札を優先して、次の展開札へつなげます。');
    if (extenders.length) play.push(`2. 次に ${extenders.join(' / ')} などの展開補助を使い、盤面のモンスター数やリソースを増やします。`);
    else play.push('2. 主役カードを無理に使い切らず、次のターンに続く手札・墓地リソースを残します。');
    if (finishers.length) play.push(`3. 盤面が整ったら ${finishers.join(' / ')} などを勝ち筋・フィニッシャー候補として使います。`);
    else play.push('3. 盤面が整ったら、テーマの主力カードで継続的にアドバンテージを取ります。');
    if (disruption.length) play.push(`4. ${disruption.join(' / ')} などの妨害は、相手の初動や重要なEXデッキ展開まで温存するのが基本です。`);
    if (draw.length) play.push(`5. 手札が足りない場合は ${draw.join(' / ')} などのドロー札で次の動きを確保します。`);
    if (deck.jokeMode) {
      play.push('');
      play.push('【このネタ型の狙い】');
      play.push(jokeStrategyText(deck.jokeType));
    }
    play.push('');
    play.push('【注意】');
    play.push('自動生成のため、個別カードの「このターン○○しか特殊召喚できない」などの制約は実戦前にカード本文で最終確認してください。');

    return { reason: reasons.join('\n'), play: play.join('\n') };
  }

  function renderDeck() {
    const deck = state.deck;
    if (!deck) return;

    $('deckTitle').textContent = deck.name;
    const jokeMeta = deck.jokeMode ? ` / ${JOKE_TYPE_LABELS[deck.jokeType] || deck.jokeType} / ネタ度: ${JOKE_LEVEL_LABELS[deck.jokeLevel] || deck.jokeLevel}` : '';
    $('deckMeta').textContent = `${profileLabel(deck.profile)}${jokeMeta} / 規制: ${state.regulation.name || 'custom'} / ${new Date(deck.generated_at).toLocaleString('ja-JP')}`;

    renderDeckList($('mainDeck'), deck.main, deck.theme);
    renderDeckList($('extraDeck'), deck.extra, deck.theme);

    const mainCount = deck.main.reduce((s, x) => s + x.qty, 0);
    const extraCount = deck.extra.reduce((s, x) => s + x.qty, 0);
    $('mainCount').textContent = mainCount;
    $('extraCount').textContent = extraCount;

    const all = [...deck.main, ...deck.extra];
    const rarityCounts = { N: 0, R: 0, SR: 0, UR: 0, unknown: 0 };
    for (const x of all) {
      const r = getMdRarity(x.card);
      if (Object.prototype.hasOwnProperty.call(rarityCounts, r)) rarityCounts[r] += x.qty;
      else rarityCounts.unknown += x.qty;
    }
    const ur = rarityCounts.UR;
    const sr = rarityCounts.SR;
    const themeCards = deck.theme ? all.reduce((s, x) => s + ((x.card.archetype === deck.theme || String(x.card.desc || '').toLowerCase().includes(String(deck.theme).toLowerCase())) ? x.qty : 0), 0) : 0;
    const jokeIds = new Set((deck.jokeRelatedIds || []).map(String));
    const jokeCards = deck.jokeMode ? all.reduce((s, x) => s + (jokeIds.has(String(x.card.id)) ? x.qty : 0), 0) : 0;
    const forbiddenHits = all.filter(x => getLimit(x.card) === 0).length;

    $('summaryCards').innerHTML = [
      stat(mainCount, 'MAIN枚数'),
      stat(extraCount, 'EXTRA枚数'),
      stat(`N ${rarityCounts.N} / R ${rarityCounts.R} / SR ${rarityCounts.SR} / UR ${rarityCounts.UR}`, 'Master Duelレアリティ'),
      stat(deck.jokeMode ? jokeCards : themeCards, deck.jokeMode ? 'ネタ関連枚数' : 'テーマ関連枚数')
    ].join('');

    const guide = buildDeckGuide(deck);
    if ($('buildReasonText')) $('buildReasonText').textContent = guide.reason;
    if ($('playGuideText')) $('playGuideText').textContent = guide.play;

    const roleCounts = { starter: 0, disruption: 0, removal: 0, draw: 0 };
    for (const x of deck.main) {
      const d = String(x.card.desc || '').toLowerCase();
      if (/add 1|from your deck to your hand|special summon this card/i.test(d)) roleCounts.starter += x.qty;
      if (/negate|quick effect/i.test(d)) roleCounts.disruption += x.qty;
      if (/destroy|banish|return .* hand|shuffle .* deck/i.test(d)) roleCounts.removal += x.qty;
      if (/draw 1|draw 2/i.test(d)) roleCounts.draw += x.qty;
    }

    const warningText = deck.warnings.length ? `\n\n注意:\n- ${deck.warnings.join('\n- ')}` : '';
    const themeLine = `テーマ: ${deck.themeLabel || themeDisplayName(deck.theme) || '指定なし'}`;
    const jokeLines = deck.jokeMode
      ? `\nネタの方向性: ${JOKE_TYPE_LABELS[deck.jokeType] || deck.jokeType}` +
        `\nネタ内容: ${deck.jokeConcept || 'テーマ/主役カードから自動'}` +
        `\nネタ度: ${JOKE_LEVEL_LABELS[deck.jokeLevel] || deck.jokeLevel}` +
        `\nネタ関連: 約${jokeCards}枚`
      : '';
    $('analysisText').textContent =
      themeLine + jokeLines + `\n` +
      `初動/展開候補: 約${roleCounts.starter}枚\n` +
      `妨害候補: 約${roleCounts.disruption}枚\n` +
      `除去候補: 約${roleCounts.removal}枚\n` +
      `ドロー候補: 約${roleCounts.draw}枚\n` +
      `Master Duelレアリティ: N ${rarityCounts.N}枚 / R ${rarityCounts.R}枚 / SR ${rarityCounts.SR}枚 / UR ${rarityCounts.UR}枚${rarityCounts.unknown ? ` / 不明 ${rarityCounts.unknown}枚` : ''}\n` +
      `禁止設定ヒット: ${forbiddenHits}件` + warningText;

    $('copyBtn').disabled = false;
    $('jsonBtn').disabled = false;
    $('ydkBtn').disabled = false;
  }

  function renderDeckList(root, entries, theme) {
    root.classList.remove('empty');
    root.innerHTML = '';
    const showImages = imageDisplayEnabled();
    for (const entry of entries) {
      const row = document.createElement('div');
      row.className = `card-row${showImages ? '' : ' no-image'}`;
      const limit = getLimit(entry.card);
      const urls = cardImageUrls(entry.card);
      const imageHtml = showImages ? `
        <button type="button" class="card-thumb-button" title="カード画像を拡大" aria-label="${escapeHtml(displayName(entry.card))}の画像を拡大">
          ${urls.small
            ? `<img class="card-thumb" src="${escapeHtml(urls.small)}" alt="${escapeHtml(displayName(entry.card))}" loading="lazy" decoding="async" referrerpolicy="no-referrer" />`
            : '<span class="card-thumb-fallback">画像なし</span>'}
        </button>` : '';
      row.innerHTML = `
        ${imageHtml}
        <div class="qty">×${entry.qty}</div>
        <div>
          <div class="card-name">${escapeHtml(displayName(entry.card))}</div>
          <div class="card-sub">${escapeHtml(entry.reason || reasonFor(entry.card, theme))}${limit < 3 ? ` / 上限${limit}` : ''}</div>
        </div>
        <div class="rarity md-rarity rarity-${escapeHtml((getMdRarity(entry.card) || 'unknown').toLowerCase())} ${limit < 3 ? `limit${limit}` : ''}" title="${escapeHtml(mdRarityLabel(entry.card))}">
          <span class="rarity-prefix">MD</span><strong>${escapeHtml(getMdRarity(entry.card) || '-')}</strong>
        </div>
      `;
      const btn = row.querySelector('.card-thumb-button');
      const thumb = row.querySelector('.card-thumb');
      if (btn) btn.addEventListener('click', () => openCardImage(entry.card));
      if (thumb) thumb.addEventListener('error', () => {
        thumb.remove();
        if (btn) {
          const fallback = document.createElement('span');
          fallback.className = 'card-thumb-fallback';
          fallback.textContent = '画像なし';
          btn.appendChild(fallback);
        }
      }, { once: true });
      root.appendChild(row);
    }
  }

  function stat(value, label) {
    return `<div class="stat"><strong>${escapeHtml(String(value))}</strong><span>${escapeHtml(label)}</span></div>`;
  }

  function profileLabel(v) {
    return ({ balanced: 'バランス', first: '先攻寄り', second: '後攻寄り', budget: '低レア優先', joke: 'ネタデッキ' })[v] || v;
  }

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
  }

  function setHint(text, cls = '') {
    const el = $('buildHint');
    el.textContent = text;
    el.className = `hint ${cls}`.trim();
  }

  async function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('MasterDuelAutoDeck', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('cache')) db.createObjectStore('cache');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function cacheGet(key) {
    try {
      const db = await openDb();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction('cache', 'readonly');
        const req = tx.objectStore('cache').get(key);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return null;
    }
  }

  async function cacheSet(key, value) {
    try {
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const tx = db.transaction('cache', 'readwrite');
        tx.objectStore('cache').put(value, key);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      // Non-fatal: app still works without persistent cache.
    }
  }

  function indexCards(cards) {
    state.cards = cards
      .filter(c => c && c.id && c.name)
      .map(c => {
        const out = (!c.md_rarity && Array.isArray(c.misc_info) && c.misc_info[0] && c.misc_info[0].md_rarity)
          ? { ...c, md_rarity: c.misc_info[0].md_rarity }
          : { ...c };
        const jp = state.jpNameCache[String(out.id)];
        if (jp) {
          if (jp.jp_name) out.jp_name = jp.jp_name;
          if (jp.jp_ruby) out.jp_ruby = jp.jp_ruby;
          if (jp.en_name) out.jp_source_en_name = jp.en_name;
        }
        return out;
      });
    state.cardByName = new Map(state.cards.map(c => [normalizeText(c.name), c]));
    state.cardById = new Map(state.cards.map(c => [String(c.id), c]));
    state.archetypes = [...new Set(state.cards.map(c => c.archetype).filter(Boolean))].sort((a, b) => a.localeCompare(b));
    rebuildJapaneseIndex();

    populateThemeSelect();
  }

  async function loadCards({ force = false } = {}) {
    const status = $('syncStatus');
    const btn = $('syncBtn');
    btn.disabled = true;
    status.textContent = '確認中…';

    try {
      const cached = await cacheGet(CACHE_KEY);
      const freshEnough = cached && cached.timestamp && Date.now() - cached.timestamp < CACHE_MAX_AGE && Array.isArray(cached.cards);
      if (freshEnough && !force) {
        indexCards(cached.cards);
        status.textContent = `キャッシュ ${state.cards.length.toLocaleString()}枚`;
        setHint('カードDB準備完了。Master Duelレアリティ（N/R/SR/UR）も取得済みです。テーマを指定して自動構築できます。', 'ok');
        return;
      }

      status.textContent = 'API同期中…';
      const res = await fetch(API_URL, { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (!json || !Array.isArray(json.data)) throw new Error('カード一覧の形式が不正です');
      indexCards(json.data);
      await cacheSet(CACHE_KEY, { timestamp: Date.now(), cards: json.data });
      status.textContent = `同期済み ${state.cards.length.toLocaleString()}枚`;
      setHint('カードDB同期完了。テーマを指定して自動構築できます。', 'ok');
    } catch (err) {
      const cached = await cacheGet(CACHE_KEY);
      if (cached && Array.isArray(cached.cards)) {
        indexCards(cached.cards);
        status.textContent = `オフラインキャッシュ ${state.cards.length.toLocaleString()}枚`;
        setHint(`API同期失敗のため保存済みDBを使用します: ${err.message}`, 'notice');
      } else {
        status.textContent = '同期失敗';
        setHint(`カードDBを取得できません: ${err.message}`, 'error');
      }
    } finally {
      btn.disabled = false;
    }
  }

  function saveRegulation() {
    localStorage.setItem(REG_KEY, JSON.stringify(state.regulation));
    $('regJson').value = JSON.stringify(state.regulation, null, 2);
    if ($('regPreset')) $('regPreset').value = state.regulation.preset_id || 'custom';
  }

  function clonePreset(id) {
    const preset = PRESETS[id];
    if (!preset) return null;
    return JSON.parse(JSON.stringify({ ...preset, preset_id: id }));
  }

  function loadRegulation() {
    let loaded = false;
    try {
      const raw = localStorage.getItem(REG_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (data && typeof data === 'object' && data.limits && typeof data.limits === 'object') {
          state.regulation = data;
          loaded = true;
        }
      }
    } catch {}
    if (!loaded && PRESETS.current) state.regulation = clonePreset('current');
    $('regJson').value = JSON.stringify(state.regulation, null, 2);
    if ($('regPreset')) $('regPreset').value = state.regulation.preset_id || 'custom';
    if (!loaded) localStorage.setItem(REG_KEY, JSON.stringify(state.regulation));
  }

  function applyRegPreset() {
    const id = $('regPreset').value;
    if (id === 'custom') {
      state.regulation.preset_id = 'custom';
      saveRegulation();
      setHint('カスタム規制モードに切り替えました。', 'ok');
      return;
    }
    const preset = clonePreset(id);
    if (!preset) {
      setHint('規制プリセットが見つかりません。', 'error');
      return;
    }
    state.regulation = preset;
    saveRegulation();
    const when = id === 'upcoming' ? '2026年10月6日13:00 JST適用予定' : '2026年10月1日時点の現行';
    setHint(`${when}のMaster Duel規制プリセットを適用しました。`, 'ok');
    if (state.deck) renderDeck();
  }

  function applyRegJson() {
    try {
      const data = JSON.parse($('regJson').value);
      if (!data || typeof data !== 'object' || typeof data.limits !== 'object') throw new Error('limits オブジェクトが必要です');
      for (const key of Object.keys(data.limits)) data.limits[key] = clampLimit(data.limits[key]);
      state.regulation = { ...data, preset_id: 'custom' };
      saveRegulation();
      setHint('禁止・制限JSONを適用しました。', 'ok');
      if (state.deck) renderDeck();
    } catch (err) {
      setHint(`規制JSONを適用できません: ${err.message}`, 'error');
    }
  }

  async function addRegulation() {
    const name = $('regName').value.trim();
    const limit = clampLimit($('regLimit').value);
    if (!name) return;
    setHint('カード名を照合しています…', 'notice');
    const card = await resolveCardAsync(name);
    const key = card ? card.name : name;
    state.regulation.limits[key] = limit;
    state.regulation.preset_id = 'custom';
    $('regName').value = '';
    if ($('regPreset')) $('regPreset').value = 'custom';
    saveRegulation();
    setHint(`「${card ? displayName(card) : key}」の上限を${limit}枚に設定しました。`, 'ok');
    if (state.deck) renderDeck();
  }

  function resetRegulation() {
    state.regulation = PRESETS.current ? clonePreset('current') : { name: 'Master Duel custom regulation', effective_date: '', source: 'User-maintained. Confirm with the in-game Forbidden/Limited list.', limits: {}, preset_id: 'custom' };
    saveRegulation();
    setHint('禁止・制限設定を現行プリセットへ戻しました。', 'notice');
    if (state.deck) renderDeck();
  }

  function deckText(deck) {
    const lines = [];
    lines.push(deck.name, '');
    if (deck.jokeMode) {
      lines.push(`# ネタ方向: ${JOKE_TYPE_LABELS[deck.jokeType] || deck.jokeType}`);
      lines.push(`# ネタ内容: ${deck.jokeConcept || 'テーマ/主役カードから自動'}`);
      lines.push(`# ネタ度: ${JOKE_LEVEL_LABELS[deck.jokeLevel] || deck.jokeLevel}`, '');
    }
    const guide = buildDeckGuide(deck);
    lines.push('# この構築にした理由', guide.reason, '', '# 基本の動かし方', guide.play, '');
    lines.push(`# MAIN (${deck.main.reduce((s, x) => s + x.qty, 0)})`);
    for (const x of deck.main) lines.push(`${x.qty}x ${displayName(x.card)}`);
    lines.push('', `# EXTRA (${deck.extra.reduce((s, x) => s + x.qty, 0)})`);
    for (const x of deck.extra) lines.push(`${x.qty}x ${displayName(x.card)}`);
    if (deck.warnings.length) {
      lines.push('', '# 注意');
      for (const w of deck.warnings) lines.push(`- ${w}`);
    }
    return lines.join('\n');
  }

  function ydkText(deck) {
    const lines = ['#created by Master Duel Auto Deck Builder', '#main'];
    for (const x of deck.main) for (let i = 0; i < x.qty; i++) lines.push(String(x.card.id));
    lines.push('#extra');
    for (const x of deck.extra) for (let i = 0; i < x.qty; i++) lines.push(String(x.card.id));
    lines.push('!side');
    return lines.join('\r\n') + '\r\n';
  }

  async function download(filename, content, type = 'text/plain;charset=utf-8') {
    const blob = new Blob([content], { type });
    const isAppleMobile = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (isAppleMobile && typeof File !== 'undefined' && navigator.share) {
      try {
        const file = new File([blob], filename, { type });
        if (!navigator.canShare || navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          return;
        }
      } catch (err) {
        if (err && err.name === 'AbortError') return;
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function safeFilename(s) {
    return String(s || 'deck').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80);
  }

  function exportDeckJson() {
    if (!state.deck) return;
    const out = {
      name: state.deck.name,
      theme: state.deck.theme,
      profile: state.deck.profile,
      joke_mode: !!state.deck.jokeMode,
      joke_concept: state.deck.jokeConcept || null,
      joke_type: state.deck.jokeType || null,
      joke_level: state.deck.jokeLevel || null,
      generated_at: state.deck.generated_at,
      build_reason: buildDeckGuide(state.deck).reason,
      play_guide: buildDeckGuide(state.deck).play,
      main: state.deck.main.map(x => ({ id: x.card.id, name: displayName(x.card), name_ja: x.card.jp_name || null, name_en: x.card.name, qty: x.qty, rarity: getMdRarity(x.card) || null, image_url: cardImageUrls(x.card).large || null, reason: x.reason })),
      extra: state.deck.extra.map(x => ({ id: x.card.id, name: displayName(x.card), name_ja: x.card.jp_name || null, name_en: x.card.name, qty: x.qty, rarity: getMdRarity(x.card) || null, image_url: cardImageUrls(x.card).large || null, reason: x.reason })),
      warnings: state.deck.warnings
    };
    download(`${safeFilename(state.deck.name)}.json`, JSON.stringify(out, null, 2), 'application/json;charset=utf-8');
  }

  function exportYdk() {
    if (!state.deck) return;
    download(`${safeFilename(state.deck.name)}.ydk`, ydkText(state.deck));
  }

  async function copyDeck() {
    if (!state.deck) return;
    const txt = deckText(state.deck);
    try {
      await navigator.clipboard.writeText(txt);
      setHint('デッキ一覧をクリップボードへコピーしました。', 'ok');
    } catch {
      const ta = document.createElement('textarea');
      ta.value = txt;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      setHint('デッキ一覧をコピーしました。', 'ok');
    }
  }

  function updateJokeOptions() {
    const enabled = $('profileSelect')?.value === 'joke';
    if ($('jokeOptions')) $('jokeOptions').hidden = !enabled;
    if ($('buildBtn')) $('buildBtn').textContent = enabled ? 'ネタデッキを自動構築' : 'デッキを自動構築';
    const firstThemeOption = $('themeSelect')?.querySelector('option[value=""]');
    if (firstThemeOption) firstThemeOption.textContent = enabled
      ? 'テーマなしでもOK / 選択してください ▼'
      : 'テーマを選択してください ▼';
  }

  function initEvents() {
    $('syncBtn').addEventListener('click', () => loadCards({ force: true }));
    $('buildBtn').addEventListener('click', buildDeck);
    $('freeSearchBtn')?.addEventListener('click', runFreeSearch);
    $('freeSearchInput')?.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        runFreeSearch();
      }
    });
    $('freeSearchResults')?.addEventListener('click', handleFreeSearchAction);
    $('profileSelect')?.addEventListener('change', updateJokeOptions);
    $('regAddBtn').addEventListener('click', addRegulation);
    $('applyPresetBtn').addEventListener('click', applyRegPreset);
    $('applyRegBtn').addEventListener('click', applyRegJson);
    $('resetRegBtn').addEventListener('click', resetRegulation);
    $('downloadRegBtn').addEventListener('click', () => download('master-duel-regulation.json', JSON.stringify(state.regulation, null, 2), 'application/json;charset=utf-8'));
    $('regFile').addEventListener('change', async (ev) => {
      const file = ev.target.files?.[0];
      if (!file) return;
      $('regJson').value = await file.text();
      applyRegJson();
      ev.target.value = '';
    });
    $('copyBtn').addEventListener('click', copyDeck);
    $('jsonBtn').addEventListener('click', exportDeckJson);
    $('ydkBtn').addEventListener('click', exportYdk);
    $('displayLang')?.addEventListener('change', () => {
      localStorage.setItem(LANG_KEY, $('displayLang').value);
      if (state.deck) renderDeck();
    });
    $('imageDisplay')?.addEventListener('change', () => {
      localStorage.setItem(IMAGE_KEY, $('imageDisplay').value);
      if (state.deck) renderDeck();
    });
    $('cardImageClose')?.addEventListener('click', closeCardImage);
    document.querySelector('[data-close-card-modal]')?.addEventListener('click', closeCardImage);
    document.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape' && !$('cardImageModal')?.hidden) closeCardImage();
    });
  }

  async function init() {
    await loadJapaneseCache();
    loadRegulation();
    const lang = localStorage.getItem(LANG_KEY) || 'jp';
    if ($('displayLang')) $('displayLang').value = ['jp', 'both', 'en'].includes(lang) ? lang : 'jp';
    const imageDisplay = localStorage.getItem(IMAGE_KEY) || 'show';
    if ($('imageDisplay')) $('imageDisplay').value = ['show', 'hide'].includes(imageDisplay) ? imageDisplay : 'show';
    initEvents();
    populateThemeSelect();
    updateJokeOptions();
    const cached = await cacheGet(CACHE_KEY);
    if (cached && Array.isArray(cached.cards)) {
      indexCards(cached.cards);
      $('syncStatus').textContent = `保存済み ${state.cards.length.toLocaleString()}枚`;
      setHint('保存済みカードDBを読み込みました。必要なら同期ボタンで更新できます。', 'ok');
      const lastDeck = await cacheGet(LAST_DECK_KEY);
      if (lastDeck && Array.isArray(lastDeck.main) && Array.isArray(lastDeck.extra)) {
        state.deck = lastDeck;
        renderDeck();
        setHint('保存済みカードDBと前回のデッキを復元しました。必要なら同期して更新できます。', 'ok');
      }
    }
  }

  init();
})();
